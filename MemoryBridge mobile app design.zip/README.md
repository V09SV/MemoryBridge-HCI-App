
  # MemoryBridge mobile app design

  This is a code bundle for MemoryBridge mobile app design. The original project is available at https://www.figma.com/design/XYnEoqw7Vv3rWX78q3kwXC/MemoryBridge-mobile-app-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  