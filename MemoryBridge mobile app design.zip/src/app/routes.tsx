import { createBrowserRouter } from "react-router";
import { PhoneShell } from "./components/PhoneShell";
import { WelcomeScreen } from "./screens/WelcomeScreen";
import { HomeScreen } from "./screens/HomeScreen";
import { RemindersScreen } from "./screens/RemindersScreen";
import { AddReminderScreen } from "./screens/AddReminderScreen";
import { FamilyMemoryScreen } from "./screens/FamilyMemoryScreen";
import { VoiceMemoryScreen } from "./screens/VoiceMemoryScreen";
import { DailyRoutineScreen } from "./screens/DailyRoutineScreen";
import { EmergencyScreen } from "./screens/EmergencyScreen";
import { SettingsScreen } from "./screens/SettingsScreen";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: PhoneShell,
    children: [
      { index: true, Component: WelcomeScreen },
      { path: "home", Component: HomeScreen },
      { path: "reminders", Component: RemindersScreen },
      { path: "reminders/add", Component: AddReminderScreen },
      { path: "family", Component: FamilyMemoryScreen },
      { path: "voice", Component: VoiceMemoryScreen },
      { path: "routine", Component: DailyRoutineScreen },
      { path: "emergency", Component: EmergencyScreen },
      { path: "settings", Component: SettingsScreen },
    ],
  },
]);
