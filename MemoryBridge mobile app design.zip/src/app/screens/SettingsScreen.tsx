import { useApp, FontScale } from "../AppContext";
import {
  Type,
  Moon,
  Mic,
  Bell,
  Volume2,
  Info,
  Heart,
  Sun,
  ChevronRight,
  Accessibility,
  Shield,
} from "lucide-react";
import { motion } from "motion/react";

const avatarImg =
  "https://images.unsplash.com/photo-1758686254593-7c4cd55b2621?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZW5pb3IlMjB3b21hbiUyMHBvcnRyYWl0JTIwd2FybSUyMHNtaWxlfGVufDF8fHx8MTc3NjA1NjQzN3ww&ixlib=rb-4.1.0&q=80&w=400";

function Toggle({
  enabled,
  onToggle,
  color = "#4A90A4",
}: {
  enabled: boolean;
  onToggle: () => void;
  color?: string;
}) {
  return (
    <button
      onClick={onToggle}
      aria-label={enabled ? "Toggle off" : "Toggle on"}
      aria-checked={enabled}
      role="switch"
      style={{
        width: "58px",
        height: "34px",
        borderRadius: "17px",
        background: enabled ? color : "#D0D8E0",
        position: "relative",
        transition: "background 0.25s ease",
        flexShrink: 0,
      }}
    >
      <motion.div
        animate={{ x: enabled ? 26 : 2 }}
        transition={{ type: "spring", stiffness: 400, damping: 28 }}
        style={{
          width: "28px",
          height: "28px",
          borderRadius: "50%",
          background: "white",
          position: "absolute",
          top: "3px",
          left: "0px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
        }}
      />
    </button>
  );
}

const fontSizeOptions: { value: FontScale; label: string; size: number; desc: string }[] = [
  { value: "medium", label: "Medium", size: 18, desc: "Aa" },
  { value: "large", label: "Large", size: 23, desc: "Aa" },
  { value: "xlarge", label: "X-Large", size: 29, desc: "Aa" },
];

function SectionHeader({ title }: { title: string }) {
  return (
    <h2
      style={{
        fontSize: "13px",
        fontWeight: 700,
        color: "#94A3B8",
        textTransform: "uppercase",
        letterSpacing: "1.2px",
        marginBottom: "10px",
        paddingLeft: "4px",
      }}
    >
      {title}
    </h2>
  );
}

function SettingRow({
  icon,
  iconBg,
  iconColor,
  title,
  subtitle,
  right,
}: {
  icon: React.ReactNode;
  iconBg: string;
  iconColor: string;
  title: string;
  subtitle: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 py-1" style={{ padding: "14px 16px" }}>
      <div
        className="flex items-center justify-center flex-shrink-0"
        style={{ width: "44px", height: "44px", borderRadius: "13px", background: iconBg }}
      >
        {icon}
      </div>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B" }}>{title}</p>
        <p style={{ fontSize: "13px", color: "#94A3B8", marginTop: "1px" }}>{subtitle}</p>
      </div>
      {right}
    </div>
  );
}

function Divider() {
  return <div style={{ height: "1px", background: "#F0F2F5", margin: "0 16px" }} />;
}

export function SettingsScreen() {
  const {
    fontScale,
    darkMode,
    voiceGuidance,
    notifSound,
    notifVolume,
    setFontScale,
    setDarkMode,
    setVoiceGuidance,
    setNotifSound,
    setNotifVolume,
  } = useApp();

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: "linear-gradient(145deg, #3d4a57 0%, #5A6B7A 60%, #6E7F8E 100%)" }}
      >
        <div
          className="absolute rounded-full"
          style={{ width: "160px", height: "160px", top: "-65px", right: "-45px", background: "rgba(255,255,255,0.07)" }}
        />
        <div className="relative">
          <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white", marginBottom: "3px" }}>Settings</h1>
          <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.75)" }}>Customize your experience</p>
        </div>
      </div>

      {/* ── User Profile Card ── */}
      <div className="px-5 pt-4">
        <div
          className="flex items-center gap-4"
          style={{
            background: "white",
            borderRadius: "22px",
            padding: "16px",
            boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
            border: "1px solid rgba(255,255,255,0.9)",
          }}
        >
          <div
            style={{
              width: "68px",
              height: "68px",
              borderRadius: "50%",
              overflow: "hidden",
              border: "3px solid #E8F4F8",
              flexShrink: 0,
            }}
          >
            <img src={avatarImg} alt="Margaret's profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div className="flex-1">
            <p style={{ fontSize: "20px", fontWeight: 800, color: "#1E293B" }}>Margaret</p>
            <p style={{ fontSize: "14px", color: "#94A3B8" }}>MemoryBridge member</p>
            <div
              className="flex items-center gap-1 mt-1"
              style={{ background: "#EBF4EE", borderRadius: "50px", padding: "3px 10px", display: "inline-flex" }}
            >
              <Heart size={11} style={{ color: "#6B9E7A" }} fill="#6B9E7A" />
              <span style={{ fontSize: "12px", fontWeight: 600, color: "#4e8560" }}>Care Mode Active</span>
            </div>
          </div>
          <ChevronRight size={20} style={{ color: "#94A3B8" }} />
        </div>
      </div>

      <div className="px-5 pt-5 pb-6 flex flex-col gap-5">
        {/* ── Accessibility Section ── */}
        <section>
          <SectionHeader title="Accessibility" />
          <div
            className="bg-white"
            style={{ borderRadius: "22px", overflow: "hidden", boxShadow: "0 4px 18px rgba(0,0,0,0.07)" }}
          >
            {/* Font Size */}
            <div style={{ padding: "16px" }}>
              <SettingRow
                icon={<Type size={22} style={{ color: "#4A90A4" }} strokeWidth={2} />}
                iconBg="#E8F4F8"
                iconColor="#4A90A4"
                title="Font Size"
                subtitle="Adjust text size for readability"
              />
              <div className="flex gap-2 px-4 pb-4">
                {fontSizeOptions.map((opt) => {
                  const isSelected = fontScale === opt.value;
                  return (
                    <motion.button
                      key={opt.value}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setFontScale(opt.value)}
                      className="flex-1 flex flex-col items-center justify-center gap-1"
                      style={{
                        borderRadius: "14px",
                        padding: "12px 6px",
                        background: isSelected ? "#4A90A4" : "#F7F4F0",
                        minHeight: "72px",
                        border: `2px solid ${isSelected ? "#4A90A4" : "transparent"}`,
                        transition: "all 0.2s ease",
                      }}
                    >
                      <span
                        style={{
                          fontSize: `${opt.size}px`,
                          fontWeight: 800,
                          color: isSelected ? "white" : "#64748B",
                          lineHeight: 1,
                        }}
                      >
                        A
                      </span>
                      <span
                        style={{
                          fontSize: "11px",
                          fontWeight: 600,
                          color: isSelected ? "rgba(255,255,255,0.85)" : "#94A3B8",
                        }}
                      >
                        {opt.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            <Divider />

            {/* Dark Mode */}
            <SettingRow
              icon={
                darkMode ? (
                  <Moon size={22} style={{ color: "#9B8EC4" }} strokeWidth={2} />
                ) : (
                  <Sun size={22} style={{ color: "#E8884A" }} strokeWidth={2} />
                )
              }
              iconBg={darkMode ? "#F0ECFF" : "#FFF1E6"}
              iconColor={darkMode ? "#9B8EC4" : "#E8884A"}
              title="Dark Mode"
              subtitle="Easier on the eyes at night"
              right={<Toggle enabled={darkMode} onToggle={() => setDarkMode(!darkMode)} color="#9B8EC4" />}
            />
          </div>
        </section>

        {/* ── Audio & Notifications ── */}
        <section>
          <SectionHeader title="Audio & Notifications" />
          <div
            className="bg-white"
            style={{ borderRadius: "22px", overflow: "hidden", boxShadow: "0 4px 18px rgba(0,0,0,0.07)" }}
          >
            {/* Voice guidance */}
            <SettingRow
              icon={<Mic size={22} style={{ color: voiceGuidance ? "#6B9E7A" : "#94A3B8" }} strokeWidth={2} />}
              iconBg={voiceGuidance ? "#EBF4EE" : "#F0F2F5"}
              iconColor={voiceGuidance ? "#6B9E7A" : "#94A3B8"}
              title="Voice Guidance"
              subtitle="App reads instructions aloud"
              right={
                <Toggle enabled={voiceGuidance} onToggle={() => setVoiceGuidance(!voiceGuidance)} color="#6B9E7A" />
              }
            />

            <Divider />

            {/* Notification sound */}
            <SettingRow
              icon={<Bell size={22} style={{ color: notifSound ? "#E8884A" : "#94A3B8" }} strokeWidth={2} />}
              iconBg={notifSound ? "#FFF1E6" : "#F0F2F5"}
              iconColor={notifSound ? "#E8884A" : "#94A3B8"}
              title="Notification Sounds"
              subtitle="Play sound for reminders"
              right={<Toggle enabled={notifSound} onToggle={() => setNotifSound(!notifSound)} color="#E8884A" />}
            />

            <Divider />

            {/* Volume slider */}
            <div style={{ padding: "16px" }}>
              <SettingRow
                icon={<Volume2 size={22} style={{ color: "#4A90A4" }} strokeWidth={2} />}
                iconBg="#E8F4F8"
                iconColor="#4A90A4"
                title="Volume Level"
                subtitle={`${notifVolume}% volume`}
              />
              <div className="flex items-center gap-3 px-4 pb-4">
                <Volume2 size={16} style={{ color: notifSound ? "#4A90A4" : "#D0D8E0" }} strokeWidth={2} />
                <div style={{ flex: 1, position: "relative" }}>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={notifVolume}
                    onChange={(e) => setNotifVolume(Number(e.target.value))}
                    disabled={!notifSound}
                    style={{
                      width: "100%",
                      height: "6px",
                      accentColor: "#4A90A4",
                      opacity: notifSound ? 1 : 0.35,
                      cursor: notifSound ? "pointer" : "not-allowed",
                    }}
                    aria-label="Notification volume"
                  />
                </div>
                <span
                  style={{
                    fontSize: "14px",
                    fontWeight: 700,
                    color: notifSound ? "#4A90A4" : "#D0D8E0",
                    minWidth: "38px",
                    textAlign: "right",
                  }}
                >
                  {notifVolume}%
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* ── About & Privacy ── */}
        <section>
          <SectionHeader title="About & Privacy" />
          <div
            className="bg-white"
            style={{ borderRadius: "22px", overflow: "hidden", boxShadow: "0 4px 18px rgba(0,0,0,0.07)" }}
          >
            {[
              { icon: <Info size={22} style={{ color: "#4A90A4" }} strokeWidth={2} />, iconBg: "#E8F4F8", title: "App Version", subtitle: "Version 2.4.1" },
              { icon: <Accessibility size={22} style={{ color: "#6B9E7A" }} strokeWidth={2} />, iconBg: "#EBF4EE", title: "Accessibility Features", subtitle: "Large text, high contrast & more" },
              { icon: <Shield size={22} style={{ color: "#9B8EC4" }} strokeWidth={2} />, iconBg: "#F0ECFF", title: "Privacy & Data", subtitle: "Your data stays private" },
            ].map((item, i, arr) => (
              <div key={item.title}>
                <button
                  className="w-full"
                  style={{ textAlign: "left" }}
                >
                  <SettingRow
                    icon={item.icon}
                    iconBg={item.iconBg}
                    iconColor=""
                    title={item.title}
                    subtitle={item.subtitle}
                    right={<ChevronRight size={20} style={{ color: "#94A3B8" }} />}
                  />
                </button>
                {i < arr.length - 1 && <Divider />}
              </div>
            ))}
          </div>
        </section>

        {/* ── Branding ── */}
        <div className="flex flex-col items-center pt-2 pb-2 gap-3">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="flex items-center gap-2"
            style={{
              background: "white",
              borderRadius: "18px",
              padding: "12px 22px",
              boxShadow: "0 3px 12px rgba(0,0,0,0.07)",
            }}
          >
            <Heart size={18} style={{ color: "#E53935" }} fill="#E53935" />
            <span style={{ fontSize: "17px", fontWeight: 800, color: "#1E293B" }}>MemoryBridge</span>
          </motion.div>
          <p style={{ fontSize: "13px", color: "#94A3B8", textAlign: "center" }}>
            Designed with love for our elders ❤️
          </p>
        </div>
      </div>
    </div>
  );
}
