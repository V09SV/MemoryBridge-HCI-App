import { useState, useEffect, useRef } from "react";
import { Mic, Square, Play, Pause, Trash2, MicOff, Clock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface VoiceNote {
  id: number;
  title: string;
  duration: string;
  date: string;
  color: string;
  colorBg: string;
}

const initialNotes: VoiceNote[] = [
  { id: 1, title: "Grocery List", duration: "0:45", date: "Today, 9:15 AM", color: "#4A90A4", colorBg: "#E8F4F8" },
  { id: 2, title: "Doctor's Instructions", duration: "1:23", date: "Yesterday, 3:00 PM", color: "#6B9E7A", colorBg: "#EBF4EE" },
  { id: 3, title: "Family Recipe – Grandma's Pie", duration: "2:10", date: "Apr 10, 11:00 AM", color: "#E8884A", colorBg: "#FFF1E6" },
  { id: 4, title: "Birthday Gift Ideas", duration: "0:58", date: "Apr 9, 4:30 PM", color: "#9B8EC4", colorBg: "#F0ECFF" },
];

// Animated waveform bars
function WaveformBars({ isActive, color }: { isActive: boolean; color: string }) {
  const bars = [3, 5, 8, 12, 8, 14, 10, 6, 9, 13, 7, 5, 11, 8, 4];
  return (
    <div className="flex items-center gap-1" style={{ height: "28px" }}>
      {bars.map((height, i) => (
        <motion.div
          key={i}
          animate={
            isActive
              ? { height: [`${height * 2}px`, `${height * 3.5}px`, `${height * 1.5}px`, `${height * 3}px`, `${height * 2}px`] }
              : { height: "4px" }
          }
          transition={
            isActive
              ? { duration: 0.8 + Math.random() * 0.4, repeat: Infinity, ease: "easeInOut", delay: i * 0.06 }
              : { duration: 0.3 }
          }
          style={{
            width: "3px",
            borderRadius: "2px",
            background: isActive ? color : "#D0D8E0",
            minHeight: "4px",
          }}
        />
      ))}
    </div>
  );
}

export function VoiceMemoryScreen() {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [notes, setNotes] = useState(initialNotes);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [justSaved, setJustSaved] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isRecording) {
      intervalRef.current = setInterval(() => setRecordingTime((t) => t + 1), 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const handleToggleRecord = () => {
    if (isRecording) {
      setIsRecording(false);
      if (recordingTime > 0) {
        const noteColors = ["#4A90A4", "#6B9E7A", "#E8884A", "#9B8EC4"];
        const noteBgs = ["#E8F4F8", "#EBF4EE", "#FFF1E6", "#F0ECFF"];
        const ci = notes.length % noteColors.length;
        const newNote: VoiceNote = {
          id: Date.now(),
          title: `Voice Note ${notes.length + 1}`,
          duration: formatTime(recordingTime),
          date: "Just now",
          color: noteColors[ci],
          colorBg: noteBgs[ci],
        };
        setNotes((prev) => [newNote, ...prev]);
        setJustSaved(true);
        setTimeout(() => setJustSaved(false), 2500);
      }
      setRecordingTime(0);
    } else {
      setIsRecording(true);
    }
  };

  const handlePlayPause = (id: number) => setPlayingId(playingId === id ? null : id);
  const handleDelete = (id: number) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (playingId === id) setPlayingId(null);
  };

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: "linear-gradient(145deg, #7a6fa8 0%, #9B8EC4 60%, #B0A5D4 100%)" }}
      >
        <div
          className="absolute rounded-full"
          style={{ width: "160px", height: "160px", top: "-65px", right: "-45px", background: "rgba(255,255,255,0.08)" }}
        />
        <div className="relative flex items-center gap-2 mb-1">
          <div
            className="flex items-center justify-center"
            style={{ width: "32px", height: "32px", borderRadius: "10px", background: "rgba(255,255,255,0.2)" }}
          >
            <Mic size={18} color="white" strokeWidth={2} />
          </div>
          <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white" }}>Voice Notes</h1>
        </div>
        <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.8)" }}>
          {notes.length} saved recordings
        </p>

        {/* Live waveform in header when recording */}
        {isRecording && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-3 flex items-center gap-3"
            style={{ background: "rgba(255,255,255,0.15)", borderRadius: "12px", padding: "8px 14px" }}
          >
            <div
              style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#FF5252", flexShrink: 0 }}
            />
            <WaveformBars isActive={true} color="white" />
            <span style={{ fontSize: "14px", color: "white", fontWeight: 700, marginLeft: "auto" }}>
              {formatTime(recordingTime)}
            </span>
          </motion.div>
        )}
      </div>

      {/* ── Recording Section ── */}
      <div className="px-5 pt-5 pb-4">
        <div
          className="flex flex-col items-center"
          style={{
            background: "white",
            borderRadius: "26px",
            padding: "28px 20px 24px",
            boxShadow: "0 6px 28px rgba(0,0,0,0.09)",
          }}
        >
          {/* Status text */}
          <p
            style={{
              fontSize: "17px",
              fontWeight: 700,
              color: isRecording ? "#E53935" : "#5A6B7A",
              marginBottom: "20px",
              textAlign: "center",
            }}
          >
            {isRecording
              ? `Recording in progress…`
              : "Tap the microphone to start"}
          </p>

          {/* Waveform display (decorative) */}
          <div className="mb-5">
            <WaveformBars isActive={isRecording} color={isRecording ? "#E53935" : "#9B8EC4"} />
          </div>

          {/* Mic button with pulse rings */}
          <div
            className="relative flex items-center justify-center mb-4"
            style={{ width: "130px", height: "130px" }}
          >
            {isRecording && (
              <>
                <motion.div
                  animate={{ scale: [1, 1.7], opacity: [0.35, 0] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }}
                  style={{
                    position: "absolute",
                    width: "130px",
                    height: "130px",
                    borderRadius: "50%",
                    background: "#FFCDD2",
                  }}
                />
                <motion.div
                  animate={{ scale: [1, 1.4], opacity: [0.5, 0] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut", delay: 0.5 }}
                  style={{
                    position: "absolute",
                    width: "130px",
                    height: "130px",
                    borderRadius: "50%",
                    background: "#EF9A9A",
                  }}
                />
              </>
            )}

            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={handleToggleRecord}
              aria-label={isRecording ? "Stop recording" : "Start recording"}
              className="flex flex-col items-center justify-center"
              style={{
                width: "120px",
                height: "120px",
                borderRadius: "50%",
                background: isRecording
                  ? "linear-gradient(135deg, #E53935, #c62828)"
                  : "linear-gradient(135deg, #9B8EC4, #7a6fa8)",
                boxShadow: isRecording
                  ? "0 10px 32px rgba(229,57,53,0.45)"
                  : "0 10px 32px rgba(155,142,196,0.45)",
                position: "relative",
                zIndex: 1,
                transition: "all 0.25s ease",
                gap: "4px",
              }}
            >
              {isRecording ? (
                <>
                  <Square size={36} color="white" fill="white" />
                  <span style={{ fontSize: "13px", fontWeight: 700, color: "rgba(255,255,255,0.9)" }}>
                    {formatTime(recordingTime)}
                  </span>
                </>
              ) : (
                <Mic size={52} color="white" strokeWidth={1.6} />
              )}
            </motion.button>
          </div>

          <p
            style={{
              fontSize: "16px",
              fontWeight: 600,
              color: isRecording ? "#E53935" : "#9B8EC4",
              textAlign: "center",
            }}
          >
            {isRecording ? "Tap to Stop & Save" : "Tap to Start Recording"}
          </p>

          {/* Saved confirmation */}
          <AnimatePresence>
            {justSaved && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.9 }}
                style={{
                  marginTop: "14px",
                  background: "linear-gradient(135deg, #EBF4EE, #D4ECD9)",
                  borderRadius: "12px",
                  padding: "10px 20px",
                  border: "1px solid #C8E5D0",
                }}
              >
                <p style={{ fontSize: "16px", fontWeight: 700, color: "#4e8560" }}>
                  ✓ Voice note saved!
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ── Saved Notes ── */}
      <div className="px-5 pb-6">
        <h2 style={{ fontSize: "19px", fontWeight: 800, color: "#1E293B", marginBottom: "12px" }}>
          Saved Recordings
        </h2>

        {notes.length === 0 ? (
          <div className="flex flex-col items-center py-12 text-center">
            <div
              className="flex items-center justify-center mb-4"
              style={{ width: "72px", height: "72px", borderRadius: "50%", background: "#F0F2F5" }}
            >
              <MicOff size={36} style={{ color: "#D0D8E0" }} />
            </div>
            <p style={{ fontSize: "18px", color: "#94A3B8", fontWeight: 600 }}>No recordings yet</p>
            <p style={{ fontSize: "15px", color: "#B0BACB", marginTop: "4px" }}>Tap the mic above to start</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <AnimatePresence>
              {notes.map((note, index) => (
                <motion.div
                  key={note.id}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 12 }}
                  transition={{ delay: index * 0.05, duration: 0.3 }}
                >
                  <div
                    className="bg-white flex flex-col"
                    style={{
                      borderRadius: "20px",
                      padding: "14px 14px 12px",
                      boxShadow: "0 3px 14px rgba(0,0,0,0.07)",
                      borderLeft: `4px solid ${note.color}`,
                    }}
                  >
                    <div className="flex items-center gap-3">
                      {/* Play button */}
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => handlePlayPause(note.id)}
                        aria-label={playingId === note.id ? "Pause" : "Play"}
                        className="flex items-center justify-center flex-shrink-0"
                        style={{
                          width: "52px",
                          height: "52px",
                          borderRadius: "15px",
                          background: note.colorBg,
                          boxShadow: `0 3px 10px ${note.color}25`,
                        }}
                      >
                        {playingId === note.id ? (
                          <Pause size={22} style={{ color: note.color }} fill={note.color} />
                        ) : (
                          <Play size={22} style={{ color: note.color }} fill={note.color} />
                        )}
                      </motion.button>

                      {/* Info */}
                      <div style={{ flex: 1 }}>
                        <p style={{ fontSize: "16px", fontWeight: 700, color: "#1E293B" }}>{note.title}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="flex items-center gap-1" style={{ fontSize: "13px", color: "#94A3B8" }}>
                            <Clock size={12} />
                            {note.duration}
                          </span>
                          <span style={{ fontSize: "13px", color: "#94A3B8" }}>{note.date}</span>
                        </div>
                      </div>

                      {/* Delete */}
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => handleDelete(note.id)}
                        aria-label="Delete recording"
                        className="flex items-center justify-center flex-shrink-0"
                        style={{
                          width: "44px",
                          height: "44px",
                          borderRadius: "12px",
                          background: "#FFF0F0",
                        }}
                      >
                        <Trash2 size={19} style={{ color: "#E53935" }} strokeWidth={2} />
                      </motion.button>
                    </div>

                    {/* Playback progress bar */}
                    {playingId === note.id && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-3"
                      >
                        <div
                          style={{ height: "5px", borderRadius: "3px", background: "#EDE8E1", overflow: "hidden" }}
                        >
                          <motion.div
                            animate={{ width: ["0%", "100%"] }}
                            transition={{ duration: 8, ease: "linear", repeat: Infinity }}
                            style={{ height: "100%", borderRadius: "3px", background: note.color }}
                          />
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <WaveformBars isActive={true} color={note.color} />
                        </div>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
