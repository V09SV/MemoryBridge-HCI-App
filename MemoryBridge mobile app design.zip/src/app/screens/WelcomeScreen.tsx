import { useNavigate } from "react-router";
import { Heart, Shield, Brain, Bell, ChevronRight } from "lucide-react";
import { motion } from "motion/react";

const welcomeImg =
  "https://images.unsplash.com/photo-1758691031979-6128d4029604?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGRlcmx5JTIwd29tYW4lMjBzbWlsaW5nJTIwc21hcnRwaG9uZSUyMGhhcHB5fGVufDF8fHx8MTc3NTk3NjcwNXww&ixlib=rb-4.1.0&q=80&w=1080";

const features = [
  {
    icon: Bell,
    label: "Smart Reminders",
    desc: "Never miss medications or appointments",
    color: "#4A90A4",
    bg: "#E8F4F8",
  },
  {
    icon: Brain,
    label: "Memory Support",
    desc: "Voice notes and daily routines",
    color: "#6B9E7A",
    bg: "#EBF4EE",
  },
  {
    icon: Heart,
    label: "Family Connect",
    desc: "Stay close to your loved ones",
    color: "#E8884A",
    bg: "#FFF1E6",
  },
  {
    icon: Shield,
    label: "Emergency Help",
    desc: "One-tap SOS for urgent situations",
    color: "#9B8EC4",
    bg: "#F0ECFF",
  },
];

export function WelcomeScreen() {
  const navigate = useNavigate();

  return (
    <div
      className="flex flex-col min-h-full"
      style={{ background: "linear-gradient(170deg, #D6EFF8 0%, #E2F0EA 40%, #F5EFE6 100%)" }}
    >
      {/* Logo Row */}
      <motion.div
        initial={{ y: -12, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex items-center gap-3 px-6 pt-5 pb-2"
      >
        <div
          className="flex items-center justify-center"
          style={{
            width: "52px",
            height: "52px",
            borderRadius: "16px",
            background: "linear-gradient(135deg, #4A90A4, #357a8a)",
            boxShadow: "0 6px 18px rgba(74,144,164,0.35)",
          }}
        >
          <Heart size={26} color="white" fill="white" />
        </div>
        <div>
          <p style={{ fontSize: "24px", fontWeight: 800, color: "#1E293B", lineHeight: 1.2 }}>
            MemoryBridge
          </p>
          <p style={{ fontSize: "13px", color: "#64748B", fontWeight: 500 }}>
            Your Memory Companion
          </p>
        </div>
      </motion.div>

      {/* Hero image */}
      <div className="flex justify-center px-6 pt-4">
        <motion.div
          initial={{ scale: 0.82, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.1 }}
          style={{
            width: "195px",
            height: "195px",
            borderRadius: "50%",
            overflow: "hidden",
            border: "5px solid white",
            boxShadow: "0 14px 44px rgba(74,144,164,0.22), 0 4px 12px rgba(0,0,0,0.1)",
          }}
        >
          <img
            src={welcomeImg}
            alt="Elderly woman comfortably using a smartphone"
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        </motion.div>
      </div>

      {/* Tagline */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="px-6 pt-5 text-center"
      >
        <h1
          style={{ fontSize: "26px", fontWeight: 800, color: "#1E293B", lineHeight: 1.3, marginBottom: "8px" }}
        >
          Helping you remember what matters most
        </h1>
        <p style={{ fontSize: "17px", color: "#64748B", lineHeight: 1.55 }}>
          A gentle, caring assistant designed especially for you.
        </p>
      </motion.div>

      {/* Feature cards */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.48, duration: 0.55 }}
        className="grid grid-cols-2 gap-3 px-6 pt-5"
      >
        {features.map(({ icon: Icon, label, desc, color, bg }, index) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55 + index * 0.07, duration: 0.35 }}
            style={{
              background: "rgba(255,255,255,0.7)",
              borderRadius: "18px",
              padding: "14px 12px",
              backdropFilter: "blur(8px)",
              border: "1px solid rgba(255,255,255,0.8)",
              boxShadow: "0 3px 12px rgba(0,0,0,0.06)",
            }}
          >
            <div
              className="flex items-center justify-center mb-2"
              style={{ width: "38px", height: "38px", borderRadius: "11px", background: bg }}
            >
              <Icon size={20} style={{ color }} strokeWidth={2} />
            </div>
            <p style={{ fontSize: "14px", fontWeight: 800, color: "#1E293B", lineHeight: 1.25, marginBottom: "3px" }}>
              {label}
            </p>
            <p style={{ fontSize: "12px", color: "#64748B", lineHeight: 1.35 }}>{desc}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* CTA */}
      <div className="flex-1" />
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.75, duration: 0.5 }}
        className="px-6 pb-6 flex flex-col gap-3 pt-4"
      >
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate("/home")}
          className="w-full flex items-center justify-center gap-3 text-white"
          style={{
            height: "68px",
            borderRadius: "22px",
            background: "linear-gradient(135deg, #4A90A4 0%, #357a8a 100%)",
            boxShadow: "0 10px 28px rgba(74,144,164,0.42)",
            fontSize: "21px",
            fontWeight: 700,
          }}
        >
          Get Started
          <ChevronRight size={24} strokeWidth={2.5} />
        </motion.button>

        <div className="flex items-center justify-center gap-2" style={{ color: "#94A3B8" }}>
          <Shield size={14} strokeWidth={2} />
          <span style={{ fontSize: "13px" }}>Your privacy is protected. No data is shared.</span>
        </div>
      </motion.div>
    </div>
  );
}
