import { useState } from "react";
import { Phone, MessageCircle, Heart, X, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface FamilyMember {
  id: number;
  name: string;
  relationship: string;
  phone: string;
  photo: string;
  color: string;
  bg: string;
  note: string;
  lastContact: string;
}

const familyMembers: FamilyMember[] = [
  {
    id: 1,
    name: "Robert",
    relationship: "Husband",
    phone: "+1 (555) 123-4567",
    photo: "https://images.unsplash.com/photo-1560807754-c3e962f506ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGRlcmx5JTIwY291cGxlJTIwd2FybSUyMHBvcnRyYWl0JTIwb3V0ZG9vcnN8ZW58MXx8fHwxNzc2MDU2NDM1fDA&ixlib=rb-4.1.0&q=80&w=400",
    color: "#4A90A4",
    bg: "#E8F4F8",
    note: "My dear husband",
    lastContact: "Today",
  },
  {
    id: 2,
    name: "Sarah",
    relationship: "Daughter",
    phone: "+1 (555) 234-5678",
    photo: "https://images.unsplash.com/photo-1544061210-d8b25d47c166?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWRkbGUlMjBhZ2VkJTIwd29tYW4lMjBkYXVnaHRlciUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NjA1NjQzN3ww&ixlib=rb-4.1.0&q=80&w=400",
    color: "#E8884A",
    bg: "#FFF1E6",
    note: "Primary contact",
    lastContact: "Yesterday",
  },
  {
    id: 3,
    name: "Michael",
    relationship: "Son",
    phone: "+1 (555) 345-6789",
    photo: "https://images.unsplash.com/photo-1758600432277-5c76801e584a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWRkbGUlMjBhZ2VkJTIwbWFuJTIwc29uJTIwcG9ydHJhaXQlMjBzbWlsaW5nfGVufDF8fHx8MTc3NTk3NjcwNnww&ixlib=rb-4.1.0&q=80&w=400",
    color: "#6B9E7A",
    bg: "#EBF4EE",
    note: "Lives nearby",
    lastContact: "2 days ago",
  },
  {
    id: 4,
    name: "Emma",
    relationship: "Granddaughter",
    phone: "+1 (555) 456-7890",
    photo: "https://images.unsplash.com/photo-1758874960180-996bc2523a37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwZ3JhbmRkYXVnaHRlciUyMHBvcnRyYWl0JTIwc21pbGluZ3xlbnwxfHx8fDE3NzU5NzY3MTB8MA&ixlib=rb-4.1.0&q=80&w=400",
    color: "#9B8EC4",
    bg: "#F0ECFF",
    note: "Always brings joy",
    lastContact: "3 days ago",
  },
  {
    id: 5,
    name: "James",
    relationship: "Grandson",
    phone: "+1 (555) 567-8901",
    photo: "https://images.unsplash.com/photo-1726140872265-17743d19078d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMG1hbiUyMGdyYW5kc29uJTIwcG9ydHJhaXQlMjBvdXRkb29yc3xlbnwxfHx8fDE3NzU5NzY3MDZ8MA&ixlib=rb-4.1.0&q=80&w=400",
    color: "#4A90A4",
    bg: "#E8F4F8",
    note: "My little tech helper",
    lastContact: "1 week ago",
  },
  {
    id: 6,
    name: "Dorothy",
    relationship: "Sister",
    phone: "+1 (555) 678-9012",
    photo: "https://images.unsplash.com/photo-1758686254593-7c4cd55b2621?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZW5pb3IlMjB3b21hbiUyMHBvcnRyYWl0JTIwd2FybSUyMHNtaWxlfGVufDF8fHx8MTc3NjA1NjQzN3ww&ixlib=rb-4.1.0&q=80&w=400",
    color: "#E8884A",
    bg: "#FFF1E6",
    note: "We chat every Sunday",
    lastContact: "Sunday",
  },
];

export function FamilyMemoryScreen() {
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: "linear-gradient(145deg, #4e8560 0%, #6B9E7A 60%, #7DB58A 100%)" }}
      >
        <div
          className="absolute rounded-full"
          style={{ width: "160px", height: "160px", top: "-65px", right: "-45px", background: "rgba(255,255,255,0.07)" }}
        />
        <div
          className="absolute rounded-full"
          style={{ width: "70px", height: "70px", bottom: "-20px", left: "30px", background: "rgba(255,255,255,0.05)" }}
        />

        <div className="relative">
          <div className="flex items-center gap-2 mb-1">
            <div
              className="flex items-center justify-center"
              style={{ width: "32px", height: "32px", borderRadius: "10px", background: "rgba(255,255,255,0.2)" }}
            >
              <Heart size={18} color="white" fill="rgba(255,255,255,0.6)" strokeWidth={2} />
            </div>
            <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white" }}>My Family</h1>
          </div>
          <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.8)" }}>
            {familyMembers.length} family members · Tap card to call
          </p>
        </div>

        {/* Hearts decoration */}
        <div className="flex gap-2 mt-3">
          {familyMembers.map((m) => (
            <div
              key={m.id}
              style={{
                width: "28px",
                height: "28px",
                borderRadius: "50%",
                overflow: "hidden",
                border: "2px solid rgba(255,255,255,0.5)",
                background: "#EBF4EE",
              }}
            >
              <img src={m.photo} alt={m.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
          ))}
        </div>
      </div>

      {/* ── Family Grid ── */}
      <div className="px-5 pt-4 pb-6 grid grid-cols-2 gap-4">
        {familyMembers.map((member, index) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.07, duration: 0.35 }}
          >
            <div
              className="bg-white flex flex-col"
              style={{
                borderRadius: "22px",
                overflow: "hidden",
                boxShadow: "0 4px 20px rgba(0,0,0,0.09)",
                border: "1px solid rgba(255,255,255,0.8)",
              }}
            >
              {/* Photo */}
              <button
                onClick={() => setSelectedMember(member)}
                aria-label={`View ${member.name}'s details`}
                style={{ position: "relative", height: "130px", display: "block", width: "100%" }}
              >
                <img
                  src={member.photo}
                  alt={`${member.name}, ${member.relationship}`}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
                {/* Gradient overlay */}
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 0,
                    right: 0,
                    height: "60px",
                    background: "linear-gradient(to top, rgba(0,0,0,0.5), transparent)",
                  }}
                />
                {/* Relationship badge */}
                <div
                  style={{
                    position: "absolute",
                    bottom: "8px",
                    left: "8px",
                    background: member.color,
                    borderRadius: "50px",
                    padding: "3px 10px",
                  }}
                >
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "white" }}>
                    {member.relationship}
                  </span>
                </div>
                {/* Last contact badge */}
                <div
                  style={{
                    position: "absolute",
                    top: "8px",
                    right: "8px",
                    background: "rgba(255,255,255,0.9)",
                    borderRadius: "50px",
                    padding: "2px 8px",
                  }}
                >
                  <span style={{ fontSize: "10px", fontWeight: 600, color: "#5A6B7A" }}>
                    {member.lastContact}
                  </span>
                </div>
              </button>

              {/* Details */}
              <div style={{ padding: "12px" }}>
                <p style={{ fontSize: "17px", fontWeight: 800, color: "#1E293B", marginBottom: "1px" }}>
                  {member.name}
                </p>
                <p style={{ fontSize: "12px", color: "#94A3B8", marginBottom: "10px", lineHeight: 1.3 }}>
                  {member.note}
                </p>

                {/* Action buttons */}
                <div className="flex gap-2">
                  <a
                    href={`tel:${member.phone}`}
                    className="flex items-center justify-center gap-1 flex-1"
                    style={{
                      height: "44px",
                      borderRadius: "12px",
                      background: member.color,
                      boxShadow: `0 4px 12px ${member.color}40`,
                      textDecoration: "none",
                    }}
                    aria-label={`Call ${member.name}`}
                  >
                    <Phone size={17} color="white" strokeWidth={2.5} />
                    <span style={{ fontSize: "14px", fontWeight: 700, color: "white" }}>Call</span>
                  </a>
                  <a
                    href={`sms:${member.phone}`}
                    className="flex items-center justify-center"
                    style={{
                      width: "44px",
                      height: "44px",
                      borderRadius: "12px",
                      background: member.bg,
                      textDecoration: "none",
                    }}
                    aria-label={`Message ${member.name}`}
                  >
                    <MessageCircle size={19} style={{ color: member.color }} strokeWidth={2} />
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── Tip card ── */}
      <div
        className="mx-5 mb-6 flex items-center gap-3"
        style={{ background: "#EBF4EE", borderRadius: "18px", padding: "14px 16px", border: "1px solid #C8E5D0" }}
      >
        <span style={{ fontSize: "22px" }}>💡</span>
        <p style={{ fontSize: "14px", color: "#4e6a55", lineHeight: 1.5, fontWeight: 500 }}>
          Tap a family member's photo to see their details, or press <strong>Call</strong> to reach them instantly.
        </p>
      </div>

      {/* ── Contact Detail Modal ── */}
      <AnimatePresence>
        {selectedMember && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center"
            style={{ background: "rgba(0,0,0,0.55)", maxWidth: "390px", left: "50%", transform: "translateX(-50%)" }}
            onClick={() => setSelectedMember(null)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "100%",
                background: "white",
                borderRadius: "28px 28px 0 0",
                padding: "24px 20px 40px",
                boxShadow: "0 -8px 40px rgba(0,0,0,0.2)",
              }}
            >
              {/* Drag handle */}
              <div
                style={{
                  width: "40px",
                  height: "4px",
                  borderRadius: "2px",
                  background: "#D0D8E0",
                  margin: "0 auto 20px",
                }}
              />

              <div className="flex items-center gap-4 mb-5">
                <div style={{ width: "72px", height: "72px", borderRadius: "50%", overflow: "hidden", border: `3px solid ${selectedMember.color}`, flexShrink: 0 }}>
                  <img src={selectedMember.photo} alt={selectedMember.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
                <div className="flex-1">
                  <p style={{ fontSize: "22px", fontWeight: 800, color: "#1E293B" }}>{selectedMember.name}</p>
                  <p style={{ fontSize: "15px", color: selectedMember.color, fontWeight: 600 }}>{selectedMember.relationship}</p>
                  <p style={{ fontSize: "14px", color: "#94A3B8" }}>{selectedMember.note}</p>
                </div>
                <button
                  onClick={() => setSelectedMember(null)}
                  aria-label="Close"
                  style={{ width: "36px", height: "36px", borderRadius: "50%", background: "#F0F2F5", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <X size={18} style={{ color: "#64748B" }} />
                </button>
              </div>

              <div
                className="flex items-center gap-3 mb-4"
                style={{ background: "#F7F4F0", borderRadius: "14px", padding: "13px 15px" }}
              >
                <Phone size={18} style={{ color: selectedMember.color }} strokeWidth={2} />
                <div>
                  <p style={{ fontSize: "14px", color: "#94A3B8" }}>Phone Number</p>
                  <p style={{ fontSize: "18px", fontWeight: 700, color: "#1E293B" }}>{selectedMember.phone}</p>
                </div>
                <ChevronRight size={18} style={{ color: "#94A3B8", marginLeft: "auto" }} />
              </div>

              <div
                className="flex items-center gap-3 mb-6"
                style={{ background: "#F7F4F0", borderRadius: "14px", padding: "13px 15px" }}
              >
                <Heart size={18} style={{ color: selectedMember.color }} strokeWidth={2} />
                <div>
                  <p style={{ fontSize: "14px", color: "#94A3B8" }}>Last Contact</p>
                  <p style={{ fontSize: "18px", fontWeight: 700, color: "#1E293B" }}>{selectedMember.lastContact}</p>
                </div>
              </div>

              <div className="flex gap-3">
                <a
                  href={`tel:${selectedMember.phone}`}
                  className="flex items-center justify-center gap-2 flex-1"
                  style={{
                    height: "60px",
                    borderRadius: "18px",
                    background: selectedMember.color,
                    boxShadow: `0 6px 20px ${selectedMember.color}45`,
                    textDecoration: "none",
                  }}
                >
                  <Phone size={22} color="white" strokeWidth={2.5} />
                  <span style={{ fontSize: "18px", fontWeight: 700, color: "white" }}>Call Now</span>
                </a>
                <a
                  href={`sms:${selectedMember.phone}`}
                  className="flex items-center justify-center gap-2"
                  style={{
                    height: "60px",
                    width: "60px",
                    borderRadius: "18px",
                    background: selectedMember.bg,
                    textDecoration: "none",
                    flexShrink: 0,
                  }}
                  aria-label="Send message"
                >
                  <MessageCircle size={24} style={{ color: selectedMember.color }} strokeWidth={2} />
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}