import { useState } from "react";
import type { ElementType } from "react";
import { useNavigate } from "react-router";
import {
  Bell,
  Plus,
  Mic,
  ChevronRight,
  Users,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Circle,
  Pill,
  Phone,
  Stethoscope,
  Footprints,
  Sparkles,
} from "lucide-react";
import { motion } from "motion/react";

const avatarImg =
  "https://images.unsplash.com/photo-1758686254593-7c4cd55b2621?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZW5pb3IlMjB3b21hbiUyMHBvcnRyYWl0JTIwd2FybSUyMHNtaWxlfGVufDF8fHx8MTc3NjA1NjQzN3ww&ixlib=rb-4.1.0&q=80&w=1080";

interface Reminder {
  id: number;
  title: string;
  time: string;
  done: boolean;
  color: string;
  bg: string;
  icon: ElementType;
}

const initialReminders: Reminder[] = [
  { id: 1, title: "Take Blood Pressure Pill", time: "8:00 AM", done: true, color: "#6B9E7A", bg: "#EBF4EE", icon: Pill },
  { id: 2, title: "Doctor Appointment", time: "10:30 AM", done: false, color: "#4A90A4", bg: "#E8F4F8", icon: Stethoscope },
  { id: 3, title: "Call Daughter Sarah", time: "2:00 PM", done: false, color: "#E8884A", bg: "#FFF1E6", icon: Phone },
  { id: 4, title: "Evening Walk", time: "5:30 PM", done: false, color: "#9B8EC4", bg: "#F0ECFF", icon: Footprints },
];

const navCards = [
  {
    title: "Family Memories",
    desc: "Photos & contacts",
    path: "/family",
    icon: Users,
    color: "#6B9E7A",
    bg: "linear-gradient(135deg, #EBF4EE, #D4ECD9)",
    iconBg: "#6B9E7A",
    emoji: "👨‍👩‍👧‍👦",
  },
  {
    title: "Daily Routine",
    desc: "Tasks & schedule",
    path: "/routine",
    icon: Calendar,
    color: "#E8884A",
    bg: "linear-gradient(135deg, #FFF1E6, #FFDFC4)",
    iconBg: "#E8884A",
    emoji: "📅",
  },
  {
    title: "Voice Notes",
    desc: "Audio recordings",
    path: "/voice",
    icon: Mic,
    color: "#9B8EC4",
    bg: "linear-gradient(135deg, #F0ECFF, #E0D9FF)",
    iconBg: "#9B8EC4",
    emoji: "🎙️",
  },
  {
    title: "Emergency Help",
    desc: "SOS & contacts",
    path: "/emergency",
    icon: AlertTriangle,
    color: "#E53935",
    bg: "linear-gradient(135deg, #FFE8E8, #FFCCCC)",
    iconBg: "#E53935",
    emoji: "🚨",
  },
];

export function HomeScreen() {
  const navigate = useNavigate();
  const [reminders, setReminders] = useState(initialReminders);

  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
  const greetingEmoji = hour < 12 ? "☀️" : hour < 17 ? "🌤️" : "🌙";

  const dateStr = now.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  const pendingCount = reminders.filter((r) => !r.done).length;
  const completedCount = reminders.filter((r) => r.done).length;
  const totalCount = reminders.length;
  const progressPct = Math.round((completedCount / totalCount) * 100);

  const toggleReminder = (id: number) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, done: !r.done } : r)));
  };

  return (
    <div className="flex flex-col relative" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Hero Header ── */}
      <div
        className="relative overflow-hidden"
        style={{
          background: "linear-gradient(145deg, #3A7D96 0%, #4A90A4 45%, #5BA89E 100%)",
          paddingBottom: "36px",
        }}
      >
        {/* Decorative circles */}
        <div
          className="absolute rounded-full"
          style={{ width: "200px", height: "200px", top: "-70px", right: "-50px", background: "rgba(255,255,255,0.07)" }}
        />
        <div
          className="absolute rounded-full"
          style={{ width: "100px", height: "100px", bottom: "0px", left: "-30px", background: "rgba(255,255,255,0.05)" }}
        />
        <div
          className="absolute rounded-full"
          style={{ width: "60px", height: "60px", top: "40px", right: "120px", background: "rgba(255,255,255,0.06)" }}
        />

        {/* Top row */}
        <div className="relative flex items-start justify-between gap-3 px-5 pt-4">
          <div className="flex-1">
            <div className="flex items-center gap-2" style={{ marginBottom: "2px" }}>
              <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.7)", fontWeight: 500 }}>
                {dateStr}
              </span>
            </div>
            <h1 style={{ fontSize: "24px", fontWeight: 800, color: "white", lineHeight: 1.25 }}>
              {greeting}, Margaret {greetingEmoji}
            </h1>
            <div
              className="flex items-center gap-2 mt-2"
              style={{ background: "rgba(255,255,255,0.15)", borderRadius: "50px", padding: "5px 12px", display: "inline-flex" }}
            >
              <Sparkles size={13} color="rgba(255,255,255,0.9)" />
              <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.9)", fontWeight: 600 }}>
                {pendingCount > 0 ? `${pendingCount} reminders pending` : "All tasks complete! 🎉"}
              </span>
            </div>
          </div>

          {/* Avatar */}
          <button
            onClick={() => navigate("/settings")}
            aria-label="Open Settings"
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "50%",
              overflow: "hidden",
              border: "3px solid rgba(255,255,255,0.6)",
              boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
              flexShrink: 0,
            }}
          >
            <img
              src={avatarImg}
              alt="Margaret's profile"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          </button>
        </div>

        {/* Progress summary card */}
        <div
          className="relative mx-5 mt-4"
          style={{
            background: "rgba(255,255,255,0.16)",
            borderRadius: "20px",
            padding: "14px 16px",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255,255,255,0.2)",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Bell size={15} color="white" strokeWidth={2} />
              <span style={{ fontSize: "14px", color: "white", fontWeight: 600 }}>Today's Progress</span>
            </div>
            <span style={{ fontSize: "14px", color: "rgba(255,255,255,0.9)", fontWeight: 700 }}>
              {completedCount}/{totalCount} done
            </span>
          </div>
          {/* Progress bar */}
          <div style={{ height: "8px", borderRadius: "4px", background: "rgba(255,255,255,0.25)", overflow: "hidden" }}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPct}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              style={{ height: "100%", borderRadius: "4px", background: "white" }}
            />
          </div>
          <div className="flex items-center justify-between mt-2">
            <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.75)" }}>
              {progressPct}% complete
            </span>
            <button
              onClick={() => navigate("/reminders")}
              style={{
                background: "rgba(255,255,255,0.25)",
                borderRadius: "50px",
                padding: "4px 12px",
                color: "white",
                fontSize: "13px",
                fontWeight: 600,
              }}
            >
              View All →
            </button>
          </div>
        </div>
      </div>

      {/* Wave separator */}
      <div style={{ marginTop: "-1px", lineHeight: 0 }}>
        <svg viewBox="0 0 390 28" style={{ width: "100%", display: "block", fill: "#F7F4F0" }} preserveAspectRatio="none">
          <path d="M0,28 Q65,0 130,16 Q195,32 260,12 Q325,-6 390,20 L390,28 Z" />
        </svg>
      </div>

      {/* ── Content ── */}
      <div className="flex flex-col px-5 pb-6" style={{ marginTop: "-2px", gap: "20px" }}>
        {/* Today's Reminders */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: "19px", fontWeight: 800, color: "#1E293B" }}>Today's Reminders</h2>
            <button
              onClick={() => navigate("/reminders")}
              className="flex items-center gap-1"
              style={{ color: "#4A90A4", fontSize: "15px", fontWeight: 600 }}
            >
              See all <ChevronRight size={16} />
            </button>
          </div>

          <div className="flex flex-col gap-3">
            {reminders.map((reminder, index) => {
              const Icon = reminder.icon;
              return (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.06, duration: 0.35 }}
                >
                  <button
                    onClick={() => toggleReminder(reminder.id)}
                    className="flex items-center gap-3 w-full bg-white"
                    style={{
                      borderRadius: "18px",
                      padding: "13px 14px",
                      boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
                      opacity: reminder.done ? 0.65 : 1,
                      transition: "opacity 0.25s ease",
                      borderLeft: `4px solid ${reminder.color}`,
                    }}
                    aria-label={reminder.done ? `Mark "${reminder.title}" as not done` : `Mark "${reminder.title}" as done`}
                  >
                    {/* Icon */}
                    <div
                      className="flex items-center justify-center flex-shrink-0"
                      style={{ width: "44px", height: "44px", borderRadius: "13px", background: reminder.bg }}
                    >
                      <Icon size={22} style={{ color: reminder.color }} strokeWidth={2} />
                    </div>

                    {/* Text */}
                    <div className="flex-1 text-left">
                      <p
                        style={{
                          fontSize: "16px",
                          fontWeight: 700,
                          color: reminder.done ? "#94A3B8" : "#1E293B",
                          textDecoration: reminder.done ? "line-through" : "none",
                          lineHeight: 1.3,
                        }}
                      >
                        {reminder.title}
                      </p>
                      <p style={{ fontSize: "14px", color: "#94A3B8", marginTop: "2px" }}>
                        🕐 {reminder.time}
                      </p>
                    </div>

                    {/* Check state */}
                    {reminder.done ? (
                      <CheckCircle2 size={26} style={{ color: "#6B9E7A", flexShrink: 0 }} />
                    ) : (
                      <Circle size={26} style={{ color: "#D0D8E0", flexShrink: 0 }} />
                    )}
                  </button>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Quick Actions */}
        <section>
          <h2 style={{ fontSize: "19px", fontWeight: 800, color: "#1E293B", marginBottom: "12px" }}>
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => navigate("/reminders/add")}
              className="flex items-center gap-3"
              style={{
                background: "linear-gradient(135deg, #4A90A4 0%, #357a8a 100%)",
                borderRadius: "20px",
                padding: "16px 14px",
                minHeight: "72px",
                boxShadow: "0 6px 20px rgba(74,144,164,0.35)",
              }}
            >
              <div
                className="flex items-center justify-center flex-shrink-0"
                style={{ width: "40px", height: "40px", borderRadius: "12px", background: "rgba(255,255,255,0.22)" }}
              >
                <Plus size={22} color="white" strokeWidth={2.5} />
              </div>
              <span style={{ fontSize: "16px", fontWeight: 700, color: "white", textAlign: "left", lineHeight: 1.25 }}>
                Add Reminder
              </span>
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => navigate("/voice")}
              className="flex items-center gap-3"
              style={{
                background: "linear-gradient(135deg, #6B9E7A 0%, #4e8560 100%)",
                borderRadius: "20px",
                padding: "16px 14px",
                minHeight: "72px",
                boxShadow: "0 6px 20px rgba(107,158,122,0.35)",
              }}
            >
              <div
                className="flex items-center justify-center flex-shrink-0"
                style={{ width: "40px", height: "40px", borderRadius: "12px", background: "rgba(255,255,255,0.22)" }}
              >
                <Mic size={22} color="white" strokeWidth={2.5} />
              </div>
              <span style={{ fontSize: "16px", fontWeight: 700, color: "white", textAlign: "left", lineHeight: 1.25 }}>
                Voice Note
              </span>
            </motion.button>
          </div>
        </section>

        {/* Main Menu Cards */}
        <section>
          <h2 style={{ fontSize: "19px", fontWeight: 800, color: "#1E293B", marginBottom: "12px" }}>
            Main Menu
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {navCards.map((card, index) => {
              const Icon = card.icon;
              return (
                <motion.button
                  key={card.path}
                  whileTap={{ scale: 0.95 }}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + index * 0.07, duration: 0.35 }}
                  onClick={() => navigate(card.path)}
                  className="flex flex-col items-start"
                  style={{
                    background: card.bg,
                    borderRadius: "22px",
                    padding: "18px 14px",
                    minHeight: "130px",
                    boxShadow: "0 3px 14px rgba(0,0,0,0.08)",
                    border: "1px solid rgba(255,255,255,0.8)",
                  }}
                >
                  <div
                    className="flex items-center justify-center mb-3"
                    style={{
                      width: "50px",
                      height: "50px",
                      borderRadius: "15px",
                      background: card.iconBg,
                      boxShadow: `0 4px 14px ${card.iconBg}55`,
                    }}
                  >
                    <Icon size={24} color="white" strokeWidth={2} />
                  </div>
                  <p style={{ fontSize: "15px", fontWeight: 800, color: "#1E293B", lineHeight: 1.25, textAlign: "left" }}>
                    {card.title}
                  </p>
                  <p style={{ fontSize: "13px", color: "#64748B", textAlign: "left", marginTop: "3px" }}>
                    {card.desc}
                  </p>
                </motion.button>
              );
            })}
          </div>
        </section>

        {/* Floating SOS button */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
          className="flex justify-end"
        >
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate("/emergency")}
            aria-label="Emergency SOS"
            className="flex items-center gap-2"
            style={{
              background: "linear-gradient(135deg, #E53935, #b71c1c)",
              borderRadius: "50px",
              padding: "14px 22px",
              boxShadow: "0 8px 28px rgba(229,57,53,0.45)",
              minHeight: "56px",
            }}
          >
            <AlertTriangle size={22} color="white" fill="rgba(255,255,255,0.25)" strokeWidth={2.5} />
            <span style={{ fontSize: "16px", fontWeight: 800, color: "white", letterSpacing: "1px" }}>
              SOS
            </span>
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}