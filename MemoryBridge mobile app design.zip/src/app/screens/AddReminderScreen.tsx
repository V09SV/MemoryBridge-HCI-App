import { useState } from "react";
import { useNavigate } from "react-router";
import {
  ArrowLeft,
  Bell,
  Mic,
  Repeat,
  Clock,
  Check,
  Pill,
  Phone,
  Stethoscope,
  Utensils,
  Moon,
  Footprints,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const reminderTypes = [
  { id: "medication", label: "Medication", icon: Pill, color: "#6B9E7A", bg: "#EBF4EE" },
  { id: "health", label: "Health", icon: Stethoscope, color: "#4A90A4", bg: "#E8F4F8" },
  { id: "family", label: "Family", icon: Phone, color: "#E8884A", bg: "#FFF1E6" },
  { id: "meal", label: "Meal", icon: Utensils, color: "#E8884A", bg: "#FFF1E6" },
  { id: "exercise", label: "Exercise", icon: Footprints, color: "#9B8EC4", bg: "#F0ECFF" },
  { id: "sleep", label: "Sleep", icon: Moon, color: "#5A6B7A", bg: "#F0F2F5" },
];

const repeatOptions = ["Once", "Daily", "Weekly", "Weekdays"];

export function AddReminderScreen() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("08:00");
  const [selectedType, setSelectedType] = useState("medication");
  const [repeatOption, setRepeatOption] = useState("Daily");
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!title.trim()) return;
    setSaved(true);
    setTimeout(() => navigate("/reminders"), 1200);
  };

  const selectedTypeData = reminderTypes.find((t) => t.id === selectedType)!;

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="px-5 pt-4 pb-5 flex items-center gap-4"
        style={{ background: "linear-gradient(145deg, #3A7D96 0%, #4A90A4 100%)" }}
      >
        <motion.button
          whileTap={{ scale: 0.93 }}
          onClick={() => navigate(-1)}
          aria-label="Go back"
          className="flex items-center justify-center flex-shrink-0"
          style={{
            width: "46px",
            height: "46px",
            borderRadius: "14px",
            background: "rgba(255,255,255,0.2)",
          }}
        >
          <ArrowLeft size={22} color="white" strokeWidth={2.5} />
        </motion.button>
        <div>
          <h1 style={{ fontSize: "24px", fontWeight: 800, color: "white" }}>Add Reminder</h1>
          <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.75)" }}>Set up a new reminder</p>
        </div>
      </div>

      <div className="px-5 pt-5 pb-6 flex flex-col gap-5">
        {/* ── Reminder Title ── */}
        <div>
          <label
            htmlFor="reminder-title"
            style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B", display: "block", marginBottom: "10px" }}
          >
            What do you need to remember?
          </label>
          <input
            id="reminder-title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Take morning medication"
            style={{
              width: "100%",
              height: "60px",
              borderRadius: "18px",
              border: `2.5px solid ${title.trim() ? "#4A90A4" : "#E8DDD0"}`,
              padding: "0 18px",
              fontSize: "17px",
              color: "#1E293B",
              background: "white",
              outline: "none",
              boxSizing: "border-box",
              transition: "border-color 0.2s ease",
              boxShadow: title.trim() ? "0 0 0 4px rgba(74,144,164,0.1)" : "none",
            }}
          />
        </div>

        {/* ── Time Picker ── */}
        <div>
          <label
            style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B", display: "block", marginBottom: "10px" }}
          >
            <Clock size={17} style={{ display: "inline", marginRight: "7px", verticalAlign: "middle", color: "#4A90A4" }} />
            What time?
          </label>
          <div
            style={{
              background: "white",
              borderRadius: "18px",
              border: "2.5px solid #E8DDD0",
              padding: "10px 18px",
              boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
            }}
          >
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              style={{
                width: "100%",
                height: "52px",
                border: "none",
                fontSize: "30px",
                fontWeight: 800,
                color: "#4A90A4",
                background: "transparent",
                outline: "none",
              }}
              aria-label="Select reminder time"
            />
          </div>
        </div>

        {/* ── Reminder Type ── */}
        <div>
          <label
            style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B", display: "block", marginBottom: "12px" }}
          >
            <Bell size={17} style={{ display: "inline", marginRight: "7px", verticalAlign: "middle", color: "#4A90A4" }} />
            Type of Reminder
          </label>
          <div className="grid grid-cols-3 gap-2">
            {reminderTypes.map((type) => {
              const Icon = type.icon;
              const isSelected = selectedType === type.id;
              return (
                <motion.button
                  key={type.id}
                  whileTap={{ scale: 0.94 }}
                  onClick={() => setSelectedType(type.id)}
                  className="flex flex-col items-center gap-2"
                  style={{
                    borderRadius: "16px",
                    padding: "13px 8px",
                    background: isSelected ? type.bg : "white",
                    border: `2.5px solid ${isSelected ? type.color : "#E8DDD0"}`,
                    minHeight: "84px",
                    transition: "all 0.18s ease",
                    boxShadow: isSelected ? `0 4px 14px ${type.color}30` : "0 2px 8px rgba(0,0,0,0.05)",
                  }}
                >
                  <div
                    className="flex items-center justify-center"
                    style={{
                      width: "40px",
                      height: "40px",
                      borderRadius: "12px",
                      background: isSelected ? type.color : "#F0F2F5",
                    }}
                  >
                    <Icon size={21} color={isSelected ? "white" : "#94A3B8"} strokeWidth={2} />
                  </div>
                  <span
                    style={{
                      fontSize: "13px",
                      fontWeight: 700,
                      color: isSelected ? type.color : "#64748B",
                    }}
                  >
                    {type.label}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* ── Repeat ── */}
        <div>
          <label
            style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B", display: "block", marginBottom: "12px" }}
          >
            <Repeat size={17} style={{ display: "inline", marginRight: "7px", verticalAlign: "middle", color: "#4A90A4" }} />
            Repeat
          </label>
          <div className="flex flex-wrap gap-2">
            {repeatOptions.map((opt) => {
              const isSelected = repeatOption === opt;
              return (
                <motion.button
                  key={opt}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setRepeatOption(opt)}
                  style={{
                    padding: "10px 20px",
                    borderRadius: "50px",
                    fontSize: "15px",
                    fontWeight: isSelected ? 700 : 500,
                    background: isSelected ? "#4A90A4" : "white",
                    color: isSelected ? "white" : "#64748B",
                    border: `2.5px solid ${isSelected ? "#4A90A4" : "#E8DDD0"}`,
                    minHeight: "48px",
                    boxShadow: isSelected ? "0 4px 14px rgba(74,144,164,0.35)" : "0 2px 6px rgba(0,0,0,0.05)",
                    transition: "all 0.18s ease",
                  }}
                >
                  {opt}
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* ── Voice Reminder Toggle ── */}
        <div
          className="flex items-center justify-between"
          style={{
            background: "white",
            borderRadius: "18px",
            padding: "16px",
            boxShadow: "0 3px 14px rgba(0,0,0,0.07)",
            border: voiceEnabled ? "2px solid #6B9E7A" : "2px solid transparent",
            transition: "border-color 0.2s",
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="flex items-center justify-center"
              style={{
                width: "50px",
                height: "50px",
                borderRadius: "14px",
                background: voiceEnabled ? "#EBF4EE" : "#F0F2F5",
              }}
            >
              <Mic size={24} style={{ color: voiceEnabled ? "#6B9E7A" : "#94A3B8" }} strokeWidth={2} />
            </div>
            <div>
              <p style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B" }}>Voice Reminder</p>
              <p style={{ fontSize: "13px", color: "#94A3B8" }}>App speaks this reminder aloud</p>
            </div>
          </div>
          <button
            onClick={() => setVoiceEnabled(!voiceEnabled)}
            aria-label="Toggle voice reminder"
            aria-checked={voiceEnabled}
            role="switch"
            style={{
              width: "58px",
              height: "34px",
              borderRadius: "17px",
              background: voiceEnabled ? "#6B9E7A" : "#D0D8E0",
              position: "relative",
              transition: "background 0.25s ease",
              flexShrink: 0,
            }}
          >
            <motion.div
              animate={{ x: voiceEnabled ? 26 : 2 }}
              transition={{ type: "spring", stiffness: 400, damping: 28 }}
              style={{
                width: "28px",
                height: "28px",
                borderRadius: "50%",
                background: "white",
                position: "absolute",
                top: "3px",
                left: "0px",
                boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
              }}
            />
          </button>
        </div>

        {/* ── Preview Card ── */}
        {title.trim() && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex items-center gap-3"
            style={{
              background: selectedTypeData.bg,
              borderRadius: "18px",
              padding: "14px",
              border: `2px solid ${selectedTypeData.color}30`,
            }}
          >
            <div
              className="flex items-center justify-center flex-shrink-0"
              style={{ width: "46px", height: "46px", borderRadius: "13px", background: selectedTypeData.color }}
            >
              {(() => { const Icon = selectedTypeData.icon; return <Icon size={22} color="white" strokeWidth={2} />; })()}
            </div>
            <div>
              <p style={{ fontSize: "15px", fontWeight: 700, color: "#1E293B" }}>{title}</p>
              <p style={{ fontSize: "13px", color: "#64748B" }}>
                🕐 {time} · {repeatOption} · {selectedTypeData.label}
              </p>
            </div>
          </motion.div>
        )}

        {/* ── Save Button ── */}
        <AnimatePresence mode="wait">
          {saved ? (
            <motion.div
              key="saved"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full flex items-center justify-center gap-3"
              style={{
                height: "66px",
                borderRadius: "22px",
                background: "linear-gradient(135deg, #6B9E7A, #4e8560)",
                boxShadow: "0 8px 28px rgba(107,158,122,0.38)",
              }}
            >
              <Check size={28} color="white" strokeWidth={3} />
              <span style={{ fontSize: "20px", fontWeight: 700, color: "white" }}>Reminder Saved!</span>
            </motion.div>
          ) : (
            <motion.button
              key="save"
              whileTap={{ scale: 0.97 }}
              onClick={handleSave}
              disabled={!title.trim()}
              className="w-full flex items-center justify-center gap-3"
              style={{
                height: "66px",
                borderRadius: "22px",
                background: title.trim()
                  ? "linear-gradient(135deg, #4A90A4, #357a8a)"
                  : "#D0D8E0",
                boxShadow: title.trim() ? "0 8px 28px rgba(74,144,164,0.38)" : "none",
                fontSize: "19px",
                fontWeight: 700,
                color: "white",
                transition: "all 0.2s ease",
                cursor: title.trim() ? "pointer" : "not-allowed",
              }}
            >
              <Bell size={24} strokeWidth={2.5} />
              Save Reminder
            </motion.button>
          )}
        </AnimatePresence>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate(-1)}
          style={{
            height: "52px",
            borderRadius: "16px",
            background: "white",
            border: "2px solid #E8DDD0",
            fontSize: "17px",
            fontWeight: 600,
            color: "#64748B",
          }}
        >
          Cancel
        </motion.button>
      </div>
    </div>
  );
}
