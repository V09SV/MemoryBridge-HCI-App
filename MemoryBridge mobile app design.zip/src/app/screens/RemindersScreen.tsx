import { useState } from "react";
import type { ElementType } from "react";
import { useNavigate } from "react-router";
import {
  Plus,
  Pill,
  Phone,
  Stethoscope,
  Footprints,
  Moon,
  Utensils,
  Check,
  Bell,
  ChevronRight,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type ReminderCategory = "today" | "upcoming" | "all";

interface Reminder {
  id: number;
  title: string;
  time: string;
  category: string;
  icon: ElementType;
  iconColor: string;
  iconBg: string;
  done: boolean;
  isToday: boolean;
}

const initialReminders: Reminder[] = [
  { id: 1, title: "Take Blood Pressure Medication", time: "8:00 AM", category: "Medication", icon: Pill, iconColor: "#6B9E7A", iconBg: "#EBF4EE", done: true, isToday: true },
  { id: 2, title: "Doctor Appointment", time: "10:30 AM", category: "Health", icon: Stethoscope, iconColor: "#4A90A4", iconBg: "#E8F4F8", done: false, isToday: true },
  { id: 3, title: "Call Daughter Sarah", time: "2:00 PM", category: "Family", icon: Phone, iconColor: "#E8884A", iconBg: "#FFF1E6", done: false, isToday: true },
  { id: 4, title: "Evening Walk", time: "5:30 PM", category: "Exercise", icon: Footprints, iconColor: "#9B8EC4", iconBg: "#F0ECFF", done: false, isToday: true },
  { id: 5, title: "Take Vitamins", time: "8:00 PM", category: "Medication", icon: Pill, iconColor: "#6B9E7A", iconBg: "#EBF4EE", done: false, isToday: true },
  { id: 6, title: "Prepare for Bed", time: "9:30 PM", category: "Routine", icon: Moon, iconColor: "#5A6B7A", iconBg: "#F0F2F5", done: false, isToday: true },
  { id: 7, title: "Breakfast Time", time: "8:00 AM", category: "Nutrition", icon: Utensils, iconColor: "#E8884A", iconBg: "#FFF1E6", done: false, isToday: false },
  { id: 8, title: "Eye Doctor Checkup", time: "11:00 AM", category: "Health", icon: Stethoscope, iconColor: "#4A90A4", iconBg: "#E8F4F8", done: false, isToday: false },
];

// Circular progress ring
function ProgressRing({ progress, size = 80, stroke = 7 }: { progress: number; size?: number; stroke?: number }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (progress / 100) * circumference;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      {/* Track */}
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth={stroke} />
      {/* Progress */}
      <motion.circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="white"
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: dashOffset }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      />
    </svg>
  );
}

export function RemindersScreen() {
  const navigate = useNavigate();
  const [reminders, setReminders] = useState(initialReminders);
  const [activeTab, setActiveTab] = useState<ReminderCategory>("today");

  const toggleDone = (id: number) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, done: !r.done } : r)));
  };

  const filtered =
    activeTab === "all"
      ? reminders
      : activeTab === "today"
      ? reminders.filter((r) => r.isToday)
      : reminders.filter((r) => !r.isToday);

  const completedToday = reminders.filter((r) => r.isToday && r.done).length;
  const totalToday = reminders.filter((r) => r.isToday).length;
  const progress = totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;

  const tabLabels: Record<ReminderCategory, string> = { today: "Today", upcoming: "Upcoming", all: "All" };
  const tabCounts: Record<ReminderCategory, number> = {
    today: reminders.filter((r) => r.isToday).length,
    upcoming: reminders.filter((r) => !r.isToday).length,
    all: reminders.length,
  };

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: "linear-gradient(145deg, #3A7D96 0%, #4A90A4 60%, #5BA89E 100%)" }}
      >
        {/* Decorative circle */}
        <div
          className="absolute rounded-full"
          style={{ width: "150px", height: "150px", top: "-60px", right: "-40px", background: "rgba(255,255,255,0.07)" }}
        />

        {/* Title row with progress ring */}
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white", marginBottom: "3px" }}>
              My Reminders
            </h1>
            <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.75)" }}>
              {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </p>
          </div>

          {/* Circular progress ring */}
          <div className="relative flex items-center justify-center" style={{ width: "80px", height: "80px" }}>
            <ProgressRing progress={progress} size={80} stroke={7} />
            <div
              className="absolute flex flex-col items-center justify-center"
              style={{ top: 0, left: 0, right: 0, bottom: 0 }}
            >
              <span style={{ fontSize: "18px", fontWeight: 800, color: "white", lineHeight: 1 }}>
                {progress}%
              </span>
              <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.75)", fontWeight: 600, marginTop: "1px" }}>
                done
              </span>
            </div>
          </div>
        </div>

        {/* Mini stats row */}
        <div
          className="flex items-center gap-2 mt-3"
          style={{ background: "rgba(255,255,255,0.15)", borderRadius: "14px", padding: "10px 14px" }}
        >
          <Bell size={15} color="white" strokeWidth={2} />
          <span style={{ fontSize: "14px", color: "white", fontWeight: 600, flex: 1 }}>
            {completedToday} of {totalToday} completed today
          </span>
          {completedToday === totalToday && totalToday > 0 && (
            <span style={{ fontSize: "18px" }}>🎉</span>
          )}
        </div>
      </div>

      {/* ── Filter Tabs ── */}
      <div className="px-5 pt-4 pb-3 flex gap-2">
        {(["today", "upcoming", "all"] as ReminderCategory[]).map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="flex items-center gap-2 flex-1 justify-center"
              style={{
                padding: "10px 8px",
                borderRadius: "14px",
                fontSize: "14px",
                fontWeight: isActive ? 700 : 500,
                background: isActive ? "#4A90A4" : "white",
                color: isActive ? "white" : "#64748B",
                boxShadow: isActive ? "0 4px 14px rgba(74,144,164,0.35)" : "0 2px 8px rgba(0,0,0,0.06)",
                minHeight: "48px",
                transition: "all 0.2s ease",
              }}
            >
              {tabLabels[tab]}
              <span
                style={{
                  fontSize: "12px",
                  fontWeight: 700,
                  background: isActive ? "rgba(255,255,255,0.25)" : "#F0F2F5",
                  color: isActive ? "white" : "#94A3B8",
                  borderRadius: "50px",
                  padding: "1px 7px",
                }}
              >
                {tabCounts[tab]}
              </span>
            </button>
          );
        })}
      </div>

      {/* ── Reminder List ── */}
      <div className="px-5 flex flex-col gap-3 pb-4">
        <AnimatePresence>
          {filtered.map((reminder, index) => {
            const Icon = reminder.icon;
            return (
              <motion.div
                key={reminder.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 12 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
              >
                <div
                  className="bg-white flex items-center gap-3"
                  style={{
                    borderRadius: "20px",
                    padding: "14px",
                    boxShadow: reminder.done
                      ? "0 2px 8px rgba(0,0,0,0.04)"
                      : "0 4px 16px rgba(0,0,0,0.08)",
                    opacity: reminder.done ? 0.65 : 1,
                    transition: "all 0.25s ease",
                    borderLeft: `4px solid ${reminder.iconColor}`,
                  }}
                >
                  {/* Category Icon */}
                  <div
                    className="flex items-center justify-center flex-shrink-0"
                    style={{ width: "52px", height: "52px", borderRadius: "15px", background: reminder.iconBg }}
                  >
                    <Icon size={26} style={{ color: reminder.iconColor }} strokeWidth={2} />
                  </div>

                  {/* Content */}
                  <div style={{ flex: 1 }}>
                    <p
                      style={{
                        fontSize: "17px",
                        fontWeight: 700,
                        color: reminder.done ? "#94A3B8" : "#1E293B",
                        textDecoration: reminder.done ? "line-through" : "none",
                        lineHeight: 1.3,
                      }}
                    >
                      {reminder.title}
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <span style={{ fontSize: "14px", color: "#94A3B8" }}>🕐 {reminder.time}</span>
                      <span
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: reminder.iconColor,
                          background: reminder.iconBg,
                          borderRadius: "50px",
                          padding: "2px 8px",
                        }}
                      >
                        {reminder.category}
                      </span>
                    </div>
                  </div>

                  {/* Checkbox */}
                  <button
                    onClick={() => toggleDone(reminder.id)}
                    aria-label={reminder.done ? "Mark as not done" : "Mark as done"}
                    className="flex-shrink-0 flex items-center justify-center"
                    style={{
                      width: "48px",
                      height: "48px",
                      borderRadius: "14px",
                      background: reminder.done ? "#6B9E7A" : "transparent",
                      border: `2.5px solid ${reminder.done ? "#6B9E7A" : "#D0D8E0"}`,
                      transition: "all 0.2s ease",
                    }}
                  >
                    {reminder.done && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <Check size={22} color="white" strokeWidth={3} />
                      </motion.div>
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div
              className="flex items-center justify-center mb-4"
              style={{ width: "72px", height: "72px", borderRadius: "50%", background: "#F0F2F5" }}
            >
              <Bell size={36} style={{ color: "#D0D8E0" }} />
            </div>
            <p style={{ fontSize: "18px", color: "#94A3B8", fontWeight: 600 }}>No reminders here yet</p>
            <p style={{ fontSize: "15px", color: "#B0BACB", marginTop: "6px" }}>
              Tap below to add your first one
            </p>
          </div>
        )}
      </div>

      {/* ── Add Button ── */}
      <div className="px-5 pb-5">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate("/reminders/add")}
          className="w-full flex items-center justify-center gap-3 text-white"
          style={{
            height: "64px",
            borderRadius: "22px",
            background: "linear-gradient(135deg, #4A90A4, #357a8a)",
            boxShadow: "0 8px 28px rgba(74,144,164,0.38)",
            fontSize: "19px",
            fontWeight: 700,
          }}
        >
          <Plus size={26} strokeWidth={2.5} />
          Add New Reminder
        </motion.button>
      </div>

      {/* Swipe hint */}
      <div className="flex items-center justify-center gap-2 pb-3">
        <ChevronRight size={14} style={{ color: "#B0BACB", transform: "rotate(180deg)" }} />
        <span style={{ fontSize: "13px", color: "#B0BACB" }}>Tap checkbox to mark complete</span>
        <ChevronRight size={14} style={{ color: "#B0BACB" }} />
      </div>
    </div>
  );
}
