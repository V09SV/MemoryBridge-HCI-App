import { useState } from "react";
import { Phone, MapPin, AlertTriangle, Shield, X, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const emergencyContacts = [
  { id: 1, name: "Sarah", relation: "Daughter · Primary Contact", phone: "+1 (555) 234-5678", color: "#E8884A", bg: "#FFF1E6", initials: "SA" },
  { id: 2, name: "Michael", relation: "Son · Secondary Contact", phone: "+1 (555) 345-6789", color: "#6B9E7A", bg: "#EBF4EE", initials: "MI" },
  { id: 3, name: "Dr. Johnson", relation: "Family Doctor", phone: "+1 (555) 456-7890", color: "#4A90A4", bg: "#E8F4F8", initials: "DJ" },
];

export function EmergencyScreen() {
  const [sosTriggered, setSosTriggered] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleSOSPress = () => setShowConfirm(true);

  const handleConfirmSOS = () => {
    setShowConfirm(false);
    setSosTriggered(true);
    setTimeout(() => setSosTriggered(false), 5000);
  };

  return (
    <div className="flex flex-col" style={{ background: "#FFF5F5", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: "linear-gradient(145deg, #b71c1c 0%, #E53935 60%, #EF5350 100%)" }}
      >
        <div
          className="absolute rounded-full"
          style={{ width: "160px", height: "160px", top: "-65px", right: "-45px", background: "rgba(255,255,255,0.07)" }}
        />
        <div className="relative flex items-start gap-3">
          <div
            className="flex items-center justify-center flex-shrink-0"
            style={{ width: "44px", height: "44px", borderRadius: "13px", background: "rgba(255,255,255,0.2)" }}
          >
            <AlertTriangle size={24} color="white" fill="rgba(255,255,255,0.3)" strokeWidth={2.5} />
          </div>
          <div>
            <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white" }}>Emergency Help</h1>
            <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.8)" }}>
              One tap to get immediate help
            </p>
          </div>
        </div>

        {/* Status strip */}
        <div
          className="flex items-center gap-2 mt-3"
          style={{ background: "rgba(255,255,255,0.15)", borderRadius: "12px", padding: "10px 14px" }}
        >
          <Shield size={15} color="white" strokeWidth={2} />
          <span style={{ fontSize: "14px", color: "white", fontWeight: 600 }}>
            3 emergency contacts registered
          </span>
          <div
            style={{
              width: "8px",
              height: "8px",
              borderRadius: "50%",
              background: "#69F0AE",
              marginLeft: "auto",
              flexShrink: 0,
            }}
          />
        </div>
      </div>

      {/* ── SOS Alert Banner ── */}
      <AnimatePresence>
        {sosTriggered && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-4 mt-3 flex items-center gap-3"
            style={{
              background: "linear-gradient(135deg, #6B9E7A, #4e8560)",
              borderRadius: "16px",
              padding: "14px 16px",
              boxShadow: "0 6px 20px rgba(107,158,122,0.4)",
            }}
          >
            <CheckCircle2 size={24} color="white" />
            <div>
              <p style={{ fontSize: "16px", fontWeight: 800, color: "white" }}>SOS Alert Sent!</p>
              <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.85)" }}>
                Contacting Sarah & calling 911…
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── SOS Button Section ── */}
      <div
        className="mx-4 mt-4 flex flex-col items-center"
        style={{ background: "white", borderRadius: "26px", padding: "28px 20px 24px", boxShadow: "0 6px 28px rgba(0,0,0,0.09)" }}
      >
        <p style={{ fontSize: "17px", fontWeight: 700, color: "#5A6B7A", marginBottom: "24px", textAlign: "center", lineHeight: 1.5 }}>
          Press the SOS button in case of emergency
        </p>

        {/* Pulsing SOS button */}
        <div
          className="relative flex items-center justify-center mb-5"
          style={{ width: "190px", height: "190px" }}
        >
          {/* Always-on gentle pulse */}
          <motion.div
            animate={{ scale: [1, 1.2], opacity: [0.25, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeOut" }}
            style={{ position: "absolute", width: "190px", height: "190px", borderRadius: "50%", background: "#FFCDD2" }}
          />
          <motion.div
            animate={{ scale: [1, 1.13], opacity: [0.35, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeOut", delay: 0.7 }}
            style={{ position: "absolute", width: "190px", height: "190px", borderRadius: "50%", background: "#EF9A9A" }}
          />

          {/* SOS button */}
          <motion.button
            whileTap={{ scale: 0.93 }}
            onClick={handleSOSPress}
            aria-label="SOS Emergency Button – Press to get immediate help"
            className="flex flex-col items-center justify-center"
            style={{
              width: "170px",
              height: "170px",
              borderRadius: "50%",
              background: "linear-gradient(145deg, #E53935, #b71c1c)",
              boxShadow: "0 16px 48px rgba(229,57,53,0.55), 0 4px 12px rgba(0,0,0,0.2), inset 0 1px 2px rgba(255,255,255,0.15)",
              position: "relative",
              zIndex: 1,
              gap: "4px",
            }}
          >
            <AlertTriangle size={48} color="white" fill="rgba(255,255,255,0.2)" strokeWidth={2.5} />
            <span style={{ fontSize: "30px", fontWeight: 900, color: "white", letterSpacing: "4px", marginTop: "2px" }}>
              SOS
            </span>
          </motion.button>
        </div>

        <p style={{ fontSize: "15px", color: "#94A3B8", textAlign: "center", lineHeight: 1.5 }}>
          This will alert your contacts and call 911
        </p>
      </div>

      {/* ── Call 911 Direct ── */}
      <div className="px-4 pt-4">
        <a
          href="tel:911"
          className="flex items-center justify-center gap-3 w-full"
          style={{
            height: "64px",
            borderRadius: "20px",
            background: "linear-gradient(135deg, #E53935, #b71c1c)",
            boxShadow: "0 8px 24px rgba(229,57,53,0.38)",
            textDecoration: "none",
          }}
        >
          <Phone size={26} color="white" strokeWidth={2.5} />
          <span style={{ fontSize: "20px", fontWeight: 800, color: "white" }}>Call 911 Now</span>
        </a>
      </div>

      {/* ── Emergency Contacts ── */}
      <div className="px-4 pt-5 pb-2">
        <h2 style={{ fontSize: "19px", fontWeight: 800, color: "#1E293B", marginBottom: "12px" }}>
          Emergency Contacts
        </h2>
        <div className="flex flex-col gap-3">
          {emergencyContacts.map((contact, index) => (
            <motion.div
              key={contact.id}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 + index * 0.08, duration: 0.35 }}
            >
              <div
                className="bg-white flex items-center gap-3"
                style={{
                  borderRadius: "20px",
                  padding: "14px 14px",
                  boxShadow: "0 3px 14px rgba(0,0,0,0.07)",
                  borderLeft: `4px solid ${contact.color}`,
                }}
              >
                {/* Avatar initials */}
                <div
                  className="flex items-center justify-center flex-shrink-0"
                  style={{
                    width: "52px",
                    height: "52px",
                    borderRadius: "50%",
                    background: contact.bg,
                    border: `2px solid ${contact.color}30`,
                  }}
                >
                  <span style={{ fontSize: "16px", fontWeight: 800, color: contact.color }}>
                    {contact.initials}
                  </span>
                </div>

                {/* Info */}
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: "18px", fontWeight: 700, color: "#1E293B" }}>{contact.name}</p>
                  <p style={{ fontSize: "13px", color: "#94A3B8", marginBottom: "1px" }}>{contact.relation}</p>
                  <p style={{ fontSize: "14px", color: "#64748B", fontWeight: 600 }}>{contact.phone}</p>
                </div>

                {/* Call button */}
                <a
                  href={`tel:${contact.phone}`}
                  className="flex items-center justify-center flex-shrink-0"
                  style={{
                    width: "56px",
                    height: "56px",
                    borderRadius: "16px",
                    background: contact.color,
                    boxShadow: `0 4px 14px ${contact.color}50`,
                    textDecoration: "none",
                  }}
                  aria-label={`Call ${contact.name}`}
                >
                  <Phone size={24} color="white" strokeWidth={2.5} />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* ── Location Sharing ── */}
      <div className="px-4 pt-4">
        <button
          className="flex items-center gap-3 w-full"
          style={{
            background: "white",
            borderRadius: "20px",
            padding: "15px 14px",
            boxShadow: "0 3px 14px rgba(0,0,0,0.07)",
            minHeight: "68px",
            textAlign: "left",
          }}
        >
          <div
            className="flex items-center justify-center flex-shrink-0"
            style={{ width: "52px", height: "52px", borderRadius: "15px", background: "#E8F4F8" }}
          >
            <MapPin size={26} style={{ color: "#4A90A4" }} strokeWidth={2} />
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: "17px", fontWeight: 700, color: "#1E293B" }}>Share My Location</p>
            <p style={{ fontSize: "14px", color: "#94A3B8" }}>Let family know where you are</p>
          </div>
          <div
            style={{
              background: "#E8F4F8",
              borderRadius: "10px",
              padding: "6px 12px",
            }}
          >
            <span style={{ fontSize: "14px", fontWeight: 600, color: "#4A90A4" }}>Share</span>
          </div>
        </button>
      </div>

      {/* ── Safety Reminder ── */}
      <div
        className="mx-4 mt-4 mb-6 flex items-start gap-3"
        style={{ background: "#FFF1E6", borderRadius: "18px", padding: "14px 16px", border: "1px solid #FFD8B0" }}
      >
        <span style={{ fontSize: "22px", flexShrink: 0 }}>⚠️</span>
        <p style={{ fontSize: "14px", color: "#7A4A1E", lineHeight: 1.55 }}>
          Only use the SOS button in a real emergency. For non-urgent needs, contact your family directly using the buttons above.
        </p>
      </div>

      {/* ── SOS Confirmation Modal ── */}
      <AnimatePresence>
        {showConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ background: "rgba(0,0,0,0.6)", padding: "20px" }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", stiffness: 280 }}
              style={{
                width: "100%",
                maxWidth: "340px",
                background: "white",
                borderRadius: "28px",
                padding: "28px 22px",
                boxShadow: "0 24px 60px rgba(0,0,0,0.3)",
              }}
            >
              <div className="flex items-center justify-center mb-4">
                <div
                  style={{
                    width: "72px",
                    height: "72px",
                    borderRadius: "50%",
                    background: "#FFE8E8",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <AlertTriangle size={36} style={{ color: "#E53935" }} fill="rgba(229,57,53,0.2)" strokeWidth={2.5} />
                </div>
              </div>
              <h2 style={{ fontSize: "22px", fontWeight: 800, color: "#1E293B", textAlign: "center", marginBottom: "8px" }}>
                Confirm SOS Alert
              </h2>
              <p style={{ fontSize: "16px", color: "#64748B", textAlign: "center", lineHeight: 1.5, marginBottom: "22px" }}>
                This will immediately call 911 and alert all your emergency contacts.
              </p>

              <button
                onClick={handleConfirmSOS}
                className="w-full flex items-center justify-center gap-2"
                style={{
                  height: "60px",
                  borderRadius: "18px",
                  background: "linear-gradient(135deg, #E53935, #b71c1c)",
                  boxShadow: "0 8px 24px rgba(229,57,53,0.4)",
                  marginBottom: "12px",
                }}
              >
                <AlertTriangle size={22} color="white" strokeWidth={2.5} />
                <span style={{ fontSize: "18px", fontWeight: 800, color: "white" }}>Yes, Send SOS</span>
              </button>

              <button
                onClick={() => setShowConfirm(false)}
                className="w-full flex items-center justify-center gap-2"
                style={{
                  height: "52px",
                  borderRadius: "16px",
                  background: "#F0F2F5",
                  border: "none",
                }}
              >
                <X size={18} style={{ color: "#64748B" }} />
                <span style={{ fontSize: "17px", fontWeight: 600, color: "#64748B" }}>Cancel</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
