import { useState } from "react";
import type { ElementType } from "react";
import { Check, Sun, Moon, Sunrise, Droplets, Pill, Coffee, Activity, Phone, Salad, Dumbbell, BookOpen, Bed } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type TimeOfDay = "morning" | "afternoon" | "evening";

interface Task {
  id: number;
  label: string;
  done: boolean;
  period: TimeOfDay;
  icon: ElementType;
  iconColor: string;
  iconBg: string;
}

const initialTasks: Task[] = [
  // Morning
  { id: 1, label: "Drink a glass of water", done: true, period: "morning", icon: Droplets, iconColor: "#4A90A4", iconBg: "#E8F4F8" },
  { id: 2, label: "Take morning medications", done: true, period: "morning", icon: Pill, iconColor: "#6B9E7A", iconBg: "#EBF4EE" },
  { id: 3, label: "Eat a healthy breakfast", done: false, period: "morning", icon: Coffee, iconColor: "#E8884A", iconBg: "#FFF1E6" },
  { id: 4, label: "Morning gentle stretches", done: false, period: "morning", icon: Activity, iconColor: "#9B8EC4", iconBg: "#F0ECFF" },
  // Afternoon
  { id: 5, label: "Eat a balanced lunch", done: false, period: "afternoon", icon: Salad, iconColor: "#6B9E7A", iconBg: "#EBF4EE" },
  { id: 6, label: "Take afternoon pills", done: false, period: "afternoon", icon: Pill, iconColor: "#E8884A", iconBg: "#FFF1E6" },
  { id: 7, label: "30-minute walk outdoors", done: false, period: "afternoon", icon: Dumbbell, iconColor: "#4A90A4", iconBg: "#E8F4F8" },
  { id: 8, label: "Call a family member", done: false, period: "afternoon", icon: Phone, iconColor: "#9B8EC4", iconBg: "#F0ECFF" },
  // Evening
  { id: 9, label: "Eat a light dinner", done: false, period: "evening", icon: Salad, iconColor: "#6B9E7A", iconBg: "#EBF4EE" },
  { id: 10, label: "Take evening medication", done: false, period: "evening", icon: Pill, iconColor: "#9B8EC4", iconBg: "#F0ECFF" },
  { id: 11, label: "Read or listen to music", done: false, period: "evening", icon: BookOpen, iconColor: "#4A90A4", iconBg: "#E8F4F8" },
  { id: 12, label: "Prepare for bedtime", done: false, period: "evening", icon: Bed, iconColor: "#5A6B7A", iconBg: "#F0F2F5" },
];

const periods: {
  key: TimeOfDay;
  label: string;
  icon: ElementType;
  color: string;
  bg: string;
  lightBg: string;
  gradient: string;
  timeRange: string;
}[] = [
  {
    key: "morning",
    label: "Morning",
    icon: Sunrise,
    color: "#E8884A",
    bg: "#FFF1E6",
    lightBg: "#FFF8F2",
    gradient: "linear-gradient(145deg, #E8884A 0%, #d06a30 100%)",
    timeRange: "6 AM – 12 PM",
  },
  {
    key: "afternoon",
    label: "Afternoon",
    icon: Sun,
    color: "#4A90A4",
    bg: "#E8F4F8",
    lightBg: "#F0F8FC",
    gradient: "linear-gradient(145deg, #3A7D96 0%, #4A90A4 100%)",
    timeRange: "12 PM – 6 PM",
  },
  {
    key: "evening",
    label: "Evening",
    icon: Moon,
    color: "#9B8EC4",
    bg: "#F0ECFF",
    lightBg: "#F7F4FF",
    gradient: "linear-gradient(145deg, #7a6fa8 0%, #9B8EC4 100%)",
    timeRange: "6 PM – 10 PM",
  },
];

export function DailyRoutineScreen() {
  const [tasks, setTasks] = useState(initialTasks);
  const [activeTab, setActiveTab] = useState<TimeOfDay>("morning");

  const toggleTask = (id: number) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  };

  const currentPeriod = periods.find((p) => p.key === activeTab)!;
  const periodTasks = tasks.filter((t) => t.period === activeTab);
  const doneCount = periodTasks.filter((t) => t.done).length;
  const totalCount = periodTasks.length;
  const progress = totalCount > 0 ? (doneCount / totalCount) * 100 : 0;
  const allDone = tasks.filter((t) => t.done).length;
  const allTotal = tasks.length;
  const overallPct = Math.round((allDone / allTotal) * 100);

  return (
    <div className="flex flex-col" style={{ background: "#F7F4F0", minHeight: "100%" }}>
      {/* ── Header ── */}
      <div
        className="relative overflow-hidden px-5 pt-4 pb-5"
        style={{ background: currentPeriod.gradient, transition: "background 0.4s ease" }}
      >
        {/* Decorative circles */}
        <div
          className="absolute rounded-full"
          style={{ width: "160px", height: "160px", top: "-65px", right: "-45px", background: "rgba(255,255,255,0.08)" }}
        />
        <div
          className="absolute rounded-full"
          style={{ width: "80px", height: "80px", bottom: "0px", left: "-20px", background: "rgba(255,255,255,0.05)" }}
        />

        {/* Title */}
        <div className="relative flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div
                className="flex items-center justify-center"
                style={{ width: "32px", height: "32px", borderRadius: "10px", background: "rgba(255,255,255,0.2)" }}
              >
                {(() => { const Icon = currentPeriod.icon; return <Icon size={18} color="white" strokeWidth={2} />; })()}
              </div>
              <h1 style={{ fontSize: "26px", fontWeight: 800, color: "white" }}>Daily Routine</h1>
            </div>
            <p style={{ fontSize: "15px", color: "rgba(255,255,255,0.8)" }}>
              {allDone} of {allTotal} tasks complete today
            </p>
          </div>

          {/* Overall % badge */}
          <div
            className="flex flex-col items-center justify-center flex-shrink-0"
            style={{
              width: "62px",
              height: "62px",
              borderRadius: "18px",
              background: "rgba(255,255,255,0.2)",
              border: "1px solid rgba(255,255,255,0.3)",
            }}
          >
            <span style={{ fontSize: "20px", fontWeight: 800, color: "white", lineHeight: 1 }}>{overallPct}%</span>
            <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.75)", fontWeight: 600 }}>today</span>
          </div>
        </div>

        {/* Overall progress bar */}
        <div
          className="mt-3"
          style={{ background: "rgba(255,255,255,0.18)", borderRadius: "12px", padding: "10px 14px" }}
        >
          <div className="flex justify-between items-center mb-1">
            <span style={{ fontSize: "13px", color: "white", fontWeight: 600 }}>Overall Progress</span>
            <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.9)", fontWeight: 700 }}>
              {allDone}/{allTotal}
            </span>
          </div>
          <div style={{ height: "8px", borderRadius: "4px", background: "rgba(255,255,255,0.25)", overflow: "hidden" }}>
            <motion.div
              animate={{ width: `${overallPct}%` }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              style={{ height: "100%", borderRadius: "4px", background: "white" }}
            />
          </div>
        </div>
      </div>

      {/* ── Period Tabs ── */}
      <div className="px-5 pt-4 pb-3 flex gap-2">
        {periods.map((period) => {
          const Icon = period.icon;
          const isActive = activeTab === period.key;
          const pTasks = tasks.filter((t) => t.period === period.key);
          const pDone = pTasks.filter((t) => t.done).length;
          const pPct = Math.round((pDone / pTasks.length) * 100);
          return (
            <button
              key={period.key}
              onClick={() => setActiveTab(period.key)}
              className="flex flex-col items-center flex-1"
              style={{
                borderRadius: "16px",
                padding: "10px 6px",
                background: isActive ? period.color : "white",
                boxShadow: isActive ? `0 4px 16px ${period.color}45` : "0 2px 8px rgba(0,0,0,0.06)",
                minHeight: "80px",
                justifyContent: "center",
                gap: "3px",
                transition: "all 0.25s ease",
              }}
            >
              <Icon size={20} style={{ color: isActive ? "white" : period.color }} strokeWidth={2} />
              <span style={{ fontSize: "13px", fontWeight: isActive ? 700 : 600, color: isActive ? "white" : "#5A6B7A" }}>
                {period.label}
              </span>
              <span style={{ fontSize: "11px", fontWeight: 600, color: isActive ? "rgba(255,255,255,0.85)" : "#94A3B8" }}>
                {pDone}/{pTasks.length} · {pPct}%
              </span>
              {/* Mini progress bar */}
              <div
                style={{
                  width: "32px",
                  height: "3px",
                  borderRadius: "2px",
                  background: isActive ? "rgba(255,255,255,0.3)" : "#E8DDD0",
                  overflow: "hidden",
                  marginTop: "2px",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${pPct}%`,
                    borderRadius: "2px",
                    background: isActive ? "white" : period.color,
                    transition: "width 0.4s ease",
                  }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* ── Section Progress ── */}
      <div className="px-5 mb-3">
        <div
          style={{ background: currentPeriod.bg, borderRadius: "16px", padding: "13px 15px", border: `1px solid ${currentPeriod.color}22` }}
        >
          <div className="flex items-center justify-between mb-2">
            <span style={{ fontSize: "15px", fontWeight: 700, color: currentPeriod.color }}>
              {currentPeriod.label} · {currentPeriod.timeRange}
            </span>
            <span
              style={{
                fontSize: "13px",
                fontWeight: 700,
                color: doneCount === totalCount ? "#6B9E7A" : currentPeriod.color,
                background: doneCount === totalCount ? "#EBF4EE" : "rgba(255,255,255,0.6)",
                borderRadius: "50px",
                padding: "3px 10px",
              }}
            >
              {doneCount === totalCount ? "✓ Complete!" : `${doneCount}/${totalCount} done`}
            </span>
          </div>
          <div style={{ height: "8px", borderRadius: "4px", background: "rgba(0,0,0,0.08)", overflow: "hidden" }}>
            <motion.div
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              style={{ height: "100%", borderRadius: "4px", background: currentPeriod.color }}
            />
          </div>
        </div>
      </div>

      {/* ── Task List ── */}
      <div className="px-5 pb-6 flex flex-col gap-3">
        <AnimatePresence>
          {periodTasks.map((task, index) => {
            const TaskIcon = task.icon;
            return (
              <motion.button
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
                onClick={() => toggleTask(task.id)}
                className="bg-white flex items-center gap-4"
                style={{
                  borderRadius: "18px",
                  padding: "14px 16px",
                  boxShadow: task.done ? "0 2px 8px rgba(0,0,0,0.05)" : "0 4px 16px rgba(0,0,0,0.08)",
                  minHeight: "68px",
                  opacity: task.done ? 0.68 : 1,
                  transition: "all 0.25s ease",
                  textAlign: "left",
                  borderLeft: task.done ? `4px solid ${currentPeriod.color}` : "4px solid transparent",
                }}
                aria-label={task.done ? `Mark "${task.label}" as incomplete` : `Mark "${task.label}" as complete`}
              >
                {/* Task icon */}
                <div
                  className="flex items-center justify-center flex-shrink-0"
                  style={{
                    width: "44px",
                    height: "44px",
                    borderRadius: "13px",
                    background: task.done ? currentPeriod.bg : task.iconBg,
                    transition: "background 0.2s",
                  }}
                >
                  <TaskIcon
                    size={22}
                    style={{ color: task.done ? currentPeriod.color : task.iconColor }}
                    strokeWidth={2}
                  />
                </div>

                {/* Label */}
                <p
                  style={{
                    fontSize: "17px",
                    fontWeight: 600,
                    color: task.done ? "#94A3B8" : "#1E293B",
                    textDecoration: task.done ? "line-through" : "none",
                    flex: 1,
                    lineHeight: 1.3,
                  }}
                >
                  {task.label}
                </p>

                {/* Checkbox */}
                <div
                  className="flex items-center justify-center flex-shrink-0"
                  style={{
                    width: "36px",
                    height: "36px",
                    borderRadius: "10px",
                    background: task.done ? currentPeriod.color : "transparent",
                    border: `2.5px solid ${task.done ? currentPeriod.color : "#D0D8E0"}`,
                    transition: "all 0.2s ease",
                  }}
                >
                  {task.done && (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 300 }}>
                      <Check size={18} color="white" strokeWidth={3} />
                    </motion.div>
                  )}
                </div>
              </motion.button>
            );
          })}
        </AnimatePresence>

        {/* Completion celebration */}
        {doneCount === totalCount && totalCount > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="flex flex-col items-center py-6"
            style={{
              background: currentPeriod.bg,
              borderRadius: "20px",
              border: `2px solid ${currentPeriod.color}30`,
            }}
          >
            <span style={{ fontSize: "40px" }}>🎉</span>
            <p style={{ fontSize: "18px", fontWeight: 800, color: currentPeriod.color, marginTop: "8px" }}>
              {currentPeriod.label} tasks complete!
            </p>
            <p style={{ fontSize: "15px", color: "#64748B", marginTop: "4px" }}>
              Excellent work, Margaret!
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}