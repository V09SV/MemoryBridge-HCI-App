import { createContext, useContext, useState, ReactNode } from "react";

export type FontScale = "medium" | "large" | "xlarge";

interface AppSettings {
  userName: string;
  fontScale: FontScale;
  darkMode: boolean;
  voiceGuidance: boolean;
  notifSound: boolean;
  notifVolume: number;
  setFontScale: (scale: FontScale) => void;
  setDarkMode: (dark: boolean) => void;
  setVoiceGuidance: (enabled: boolean) => void;
  setNotifSound: (enabled: boolean) => void;
  setNotifVolume: (vol: number) => void;
}

const AppContext = createContext<AppSettings | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [fontScale, setFontScale] = useState<FontScale>("large");
  const [darkMode, setDarkMode] = useState(false);
  const [voiceGuidance, setVoiceGuidance] = useState(true);
  const [notifSound, setNotifSound] = useState(true);
  const [notifVolume, setNotifVolume] = useState(75);

  return (
    <AppContext.Provider
      value={{
        userName: "Margaret",
        fontScale,
        darkMode,
        voiceGuidance,
        notifSound,
        notifVolume,
        setFontScale,
        setDarkMode,
        setVoiceGuidance,
        setNotifSound,
        setNotifVolume,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
