import { Outlet, useLocation } from "react-router";
import { BottomNav } from "./BottomNav";
import { Battery, Signal, Wifi } from "lucide-react";
import { useApp } from "../AppContext";
import { useState, useEffect } from "react";

function StatusBar() {
  const [timeStr, setTimeStr] = useState("");

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })
      );
    };
    update();
    const id = setInterval(update, 30000);
    return () => clearInterval(id);
  }, []);

  return (
    <div
      className="flex-none flex items-center px-7"
      style={{ height: "48px", paddingTop: "6px" }}
    >
      <span style={{ fontSize: "15px", fontWeight: 700, color: "#1E293B", flex: 1 }}>
        {timeStr}
      </span>
      <div className="flex items-center gap-1.5" style={{ color: "#1E293B" }}>
        <Signal size={14} strokeWidth={2.2} />
        <Wifi size={14} strokeWidth={2.2} />
        <div className="flex items-center gap-0.5">
          <Battery size={18} strokeWidth={2} />
          <span style={{ fontSize: "12px", fontWeight: 600 }}>87%</span>
        </div>
      </div>
    </div>
  );
}

export function PhoneShell() {
  const location = useLocation();
  const showBottomNav = location.pathname !== "/";
  const { darkMode } = useApp();

  const bgColor = darkMode ? "#1C2333" : "#F7F4F0";
  const bgGradient = darkMode
    ? "linear-gradient(135deg, #2D3A4A 0%, #1C2333 100%)"
    : "linear-gradient(135deg, #5BA3C9 0%, #6BBFAA 35%, #8FBF9F 65%, #C9B08F 100%)";

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{ background: bgGradient }}
    >
      {/* Desktop label */}
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/55 text-sm font-medium select-none"
        style={{ textShadow: "0 1px 3px rgba(0,0,0,0.3)", letterSpacing: "0.3px" }}
      >
        MemoryBridge — Mobile Prototype
      </div>

      {/* Phone outer frame */}
      <div
        className="relative flex flex-col overflow-hidden select-none"
        style={{
          width: "390px",
          height: "844px",
          borderRadius: "52px",
          background: bgColor,
          border: "10px solid #181A28",
          boxShadow:
            "0 50px 130px rgba(0,0,0,0.55), 0 20px 40px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.2)",
        }}
      >
        {/* Side buttons */}
        {/* Volume up */}
        <div
          className="absolute"
          style={{ left: "-14px", top: "118px", width: "10px", height: "34px", background: "#181A28", borderRadius: "4px 0 0 4px" }}
        />
        {/* Volume down */}
        <div
          className="absolute"
          style={{ left: "-14px", top: "166px", width: "10px", height: "58px", background: "#181A28", borderRadius: "4px 0 0 4px" }}
        />
        {/* Silent */}
        <div
          className="absolute"
          style={{ left: "-14px", top: "100px", width: "10px", height: "32px", background: "#282A3C", borderRadius: "4px 0 0 4px" }}
        />
        {/* Power */}
        <div
          className="absolute"
          style={{ right: "-14px", top: "166px", width: "10px", height: "78px", background: "#181A28", borderRadius: "0 4px 4px 0" }}
        />

        {/* Dynamic Island */}
        <div
          className="absolute z-50"
          style={{
            top: "14px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "122px",
            height: "34px",
            background: "#0A0A12",
            borderRadius: "20px",
            boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.06)",
          }}
        />

        {/* Status Bar */}
        <StatusBar />

        {/* Subtle top shadow to separate status bar from content */}
        <div
          style={{
            height: "1px",
            background: "rgba(0,0,0,0.06)",
            flexShrink: 0,
          }}
        />

        {/* Main scrollable content */}
        <div
          className="flex-1 overflow-y-auto overflow-x-hidden"
          style={{
            background: bgColor,
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
        >
          <Outlet />
        </div>

        {/* Bottom Nav */}
        {showBottomNav && <BottomNav />}

        {/* Home Indicator */}
        <div
          className="flex-none flex items-center justify-center"
          style={{
            height: "28px",
            background: showBottomNav ? "rgba(255,255,255,0.98)" : bgColor,
          }}
        >
          <div
            style={{
              width: "130px",
              height: "5px",
              borderRadius: "3px",
              background: "#1E293B",
              opacity: 0.22,
            }}
          />
        </div>
      </div>
    </div>
  );
}
