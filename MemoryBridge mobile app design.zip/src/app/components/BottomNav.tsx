import { useNavigate, useLocation } from "react-router";
import { Home, Bell, Calendar, Users, Settings } from "lucide-react";

const navItems = [
  { icon: Home, label: "Home", path: "/home", activeColor: "#4A90A4", activeBg: "#EBF5F9" },
  { icon: Bell, label: "Reminders", path: "/reminders", activeColor: "#E8884A", activeBg: "#FFF1E6" },
  { icon: Calendar, label: "Routine", path: "/routine", activeColor: "#6B9E7A", activeBg: "#EBF4EE" },
  { icon: Users, label: "Family", path: "/family", activeColor: "#9B8EC4", activeBg: "#F0ECFF" },
  { icon: Settings, label: "Settings", path: "/settings", activeColor: "#5A6B7A", activeBg: "#F0F2F5" },
];

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div
      className="flex-none flex items-stretch border-t"
      style={{
        height: "82px",
        background: "rgba(255,255,255,0.98)",
        borderColor: "#EDE8E1",
        boxShadow: "0 -4px 20px rgba(0,0,0,0.07)",
      }}
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive =
          location.pathname === item.path ||
          (item.path === "/home" && location.pathname === "/");
        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            aria-label={item.label}
            aria-current={isActive ? "page" : undefined}
            className="flex flex-col items-center justify-center gap-1 flex-1 relative transition-all"
            style={{
              color: isActive ? item.activeColor : "#A0AEBF",
              paddingTop: "10px",
              paddingBottom: "6px",
            }}
          >
            {/* Active top indicator */}
            {isActive && (
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: "50%",
                  transform: "translateX(-50%)",
                  width: "32px",
                  height: "3px",
                  borderRadius: "0 0 4px 4px",
                  background: item.activeColor,
                }}
              />
            )}

            {/* Icon background */}
            <div
              className="flex items-center justify-center transition-all"
              style={{
                width: "44px",
                height: "32px",
                borderRadius: "10px",
                background: isActive ? item.activeBg : "transparent",
              }}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 1.8} />
            </div>

            <span
              style={{
                fontSize: "11px",
                fontWeight: isActive ? 700 : 500,
                letterSpacing: "0.2px",
              }}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
